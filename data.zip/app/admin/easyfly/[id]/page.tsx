"use client";

import { useMemo, useState, type ReactNode } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import toast from "react-hot-toast";
import {
  ChevronLeft,
  Pencil,
  Trash2,
  FileText,
  BadgeCheck,
  IdCard,
  Upload,
  Eye,
} from "lucide-react";

type RefundStatus = "none" | "pending" | "credit_note";
type ScheduleChange = "none" | "minor" | "major";
type ModeOfPayment = "card" | "bank_transfer" | "cash";
type DepositType = "office" | "home";

type BookingRow = {
  id: number;
  srNo: string;
  supplier: string;
  invoiceNumber: string;
  pnr: string;
  paxName: string;
  airlineCode: string;
  depDate: string;
  returnDate: string;
  amountPaid: number;
  amountReceived: number;
  refundStatus: RefundStatus;
  scheduleChange: ScheduleChange;
  docs: {
    invoice: boolean;
    atol: boolean;
    passport: boolean;
  };
  createdBy: number;
};

const MOCK_BOOKINGS: BookingRow[] = [
  {
    id: 101,
    srNo: "EF-2401",
    supplier: "Amadeus Hub",
    invoiceNumber: "INV-EF-1001",
    pnr: "Q7K9TP",
    paxName: "Aarav Sharma",
    airlineCode: "AI",
    depDate: "2026-05-10",
    returnDate: "2026-05-18",
    amountPaid: 42500,
    amountReceived: 46800,
    refundStatus: "none",
    scheduleChange: "none",
    docs: { invoice: true, atol: true, passport: true },
    createdBy: 2,
  },
  {
    id: 102,
    srNo: "EF-2402",
    supplier: "Skyline Consolidators",
    invoiceNumber: "INV-EF-1002",
    pnr: "M2R4XZ",
    paxName: "Priya Menon",
    airlineCode: "UK",
    depDate: "2026-05-14",
    returnDate: "2026-05-21",
    amountPaid: 36200,
    amountReceived: 35000,
    refundStatus: "pending",
    scheduleChange: "minor",
    docs: { invoice: true, atol: false, passport: true },
    createdBy: 3,
  },
  {
    id: 103,
    srNo: "EF-2403",
    supplier: "Global Fare Desk",
    invoiceNumber: "INV-EF-1003",
    pnr: "L8D1CN",
    paxName: "Rahul Nair",
    airlineCode: "6E",
    depDate: "2026-05-20",
    returnDate: "2026-05-27",
    amountPaid: 28900,
    amountReceived: 31900,
    refundStatus: "credit_note",
    scheduleChange: "major",
    docs: { invoice: true, atol: true, passport: false },
    createdBy: 2,
  },
  {
    id: 104,
    srNo: "EF-2404",
    supplier: "Amadeus Hub",
    invoiceNumber: "INV-EF-1004",
    pnr: "B4W2RY",
    paxName: "Neha Arora",
    airlineCode: "SG",
    depDate: "2026-06-02",
    returnDate: "2026-06-09",
    amountPaid: 50150,
    amountReceived: 48600,
    refundStatus: "none",
    scheduleChange: "none",
    docs: { invoice: true, atol: false, passport: true },
    createdBy: 4,
  },
  {
    id: 105,
    srNo: "EF-2405",
    supplier: "Skyline Consolidators",
    invoiceNumber: "INV-EF-1005",
    pnr: "T5V8LK",
    paxName: "Kavya Iyer",
    airlineCode: "QR",
    depDate: "2026-06-11",
    returnDate: "2026-06-20",
    amountPaid: 78400,
    amountReceived: 82100,
    refundStatus: "none",
    scheduleChange: "minor",
    docs: { invoice: true, atol: true, passport: true },
    createdBy: 3,
  },
  {
    id: 106,
    srNo: "EF-2406",
    supplier: "Direct Carrier Desk",
    invoiceNumber: "INV-EF-1006",
    pnr: "P9J3FD",
    paxName: "Sanjay Kapoor",
    airlineCode: "EK",
    depDate: "2026-06-16",
    returnDate: "2026-06-26",
    amountPaid: 91500,
    amountReceived: 88000,
    refundStatus: "pending",
    scheduleChange: "major",
    docs: { invoice: true, atol: true, passport: false },
    createdBy: 5,
  },
];

const formatInr = (amount: number) => `INR ${amount.toLocaleString("en-IN")}`;

const formatDate = (dateString: string) =>
  new Date(dateString).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

function LabelValue({ label, value, valueClassName }: { label: string; value: string; valueClassName?: string }) {
  return (
    <div className="rounded-[10px] border border-[#D9E1EA] p-3 bg-white">
      <p className="text-xs text-[#627D98]">{label}</p>
      <p className={`mt-1 text-sm font-medium text-[#102A43] ${valueClassName || ""}`}>{value}</p>
    </div>
  );
}

function DocumentCard({
  title,
  uploaded,
  icon,
}: {
  title: string;
  uploaded: boolean;
  icon: ReactNode;
}) {
  return (
    <div className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-4 space-y-3">
      <div className="flex items-center justify-between gap-2">
        <div className="inline-flex items-center gap-2 text-[#102A43] font-heading font-semibold text-sm">
          {icon}
          {title}
        </div>
        <span
          className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${
            uploaded
              ? "bg-[#009877]/12 text-[#006F57] border-[#009877]/35"
              : "bg-[#F5F7FA] text-[#627D98] border-[#D9E1EA]"
          }`}
        >
          {uploaded ? "Uploaded" : "Missing"}
        </span>
      </div>

      <div className="flex items-center gap-2">
        <button
          type="button"
          className="inline-flex items-center gap-1.5 rounded-[10px] border border-[#D9E1EA] px-3 py-1.5 text-xs font-semibold text-[#486581] hover:bg-[#F5F7FA]"
        >
          <Upload className="h-3.5 w-3.5" />
          Upload
        </button>

        {uploaded ? (
          <button
            type="button"
            className="inline-flex items-center gap-1.5 rounded-[10px] bg-[#009877] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#007B61]"
          >
            <Eye className="h-3.5 w-3.5" />
            View
          </button>
        ) : null}
      </div>
    </div>
  );
}

export default function EasyFlyBookingDetailPage() {
  const params = useParams<{ id: string }>();
  const bookingId = Number(params?.id);

  const booking = useMemo(
    () => MOCK_BOOKINGS.find((item) => item.id === bookingId),
    [bookingId],
  );

  const [isYouthCategory, setIsYouthCategory] = useState(false);
  const [modeOfPayment, setModeOfPayment] = useState<ModeOfPayment>("card");
  const [depositType, setDepositType] = useState<DepositType>("office");
  const [receiptReceived, setReceiptReceived] = useState(false);

  const [isRefund, setIsRefund] = useState(booking?.refundStatus !== "none");
  const [refundReceivedFromSupplier, setRefundReceivedFromSupplier] = useState(false);
  const [givenToCustomer, setGivenToCustomer] = useState(false);

  const [scheduleChange, setScheduleChange] = useState<ScheduleChange>(booking?.scheduleChange || "none");
  const [isReissued, setIsReissued] = useState(false);

  if (!booking) {
    return (
      <div className="font-body max-w-[1100px] mx-auto space-y-4">
        <div className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-5">
          <p className="text-sm text-[#627D98]">Booking not found.</p>
          <Link
            href="/admin/easyfly"
            className="mt-3 inline-flex items-center gap-1.5 rounded-[10px] border border-[#D9E1EA] px-3 py-2 text-sm font-semibold text-[#486581] hover:bg-[#F5F7FA]"
          >
            <ChevronLeft className="h-4 w-4" />
            Back to Bookings
          </Link>
        </div>
      </div>
    );
  }

  const totalPayment = booking.amountPaid + booking.amountReceived;
  const paymentPending = booking.amountPaid - booking.amountReceived;
  const earnings = booking.amountReceived - booking.amountPaid;

  return (
    <div className="space-y-4 font-body max-w-[1300px] mx-auto pb-4">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="space-y-2">
          <Link
            href="/admin/easyfly"
            className="inline-flex items-center gap-1.5 rounded-[10px] border border-[#D9E1EA] bg-white px-3 py-1.5 text-sm text-[#486581] hover:bg-[#F5F7FA]"
          >
            <ChevronLeft className="w-4 h-4" />
            Back
          </Link>
          <div className="flex items-center gap-2">
            <h1 className="text-[26px] leading-tight font-heading font-semibold text-[#102A43]">Booking Detail</h1>
            <span className="rounded-full bg-[#F5F7FA] border border-[#D9E1EA] px-3 py-1 text-xs text-[#486581] font-semibold">
              {booking.pnr}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            className="inline-flex items-center gap-1.5 rounded-[10px] border border-[#D9E1EA] px-3 py-2 text-sm font-semibold text-[#486581] hover:bg-[#F5F7FA]"
          >
            <Pencil className="h-4 w-4" />
            Edit
          </button>
          <button
            type="button"
            className="inline-flex items-center gap-1.5 rounded-[10px] bg-[#B42318] px-3 py-2 text-sm font-semibold text-white hover:bg-[#9E1C13]"
          >
            <Trash2 className="h-4 w-4" />
            Delete
          </button>
        </div>
      </div>

      <section className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-4">
        <h2 className="text-sm font-heading font-semibold text-[#102A43] mb-3">Booking Summary</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <LabelValue label="Supplier" value={booking.supplier} />
          <LabelValue label="Invoice Number" value={booking.invoiceNumber} />
          <LabelValue label="PNR" value={booking.pnr} />
          <LabelValue label="Pax Name" value={booking.paxName} />
          <LabelValue label="Airline Code" value={booking.airlineCode} />
          <LabelValue label="Dep Date" value={formatDate(booking.depDate)} />
          <LabelValue label="Return Date" value={formatDate(booking.returnDate)} />
          <LabelValue label="Amount Paid" value={formatInr(booking.amountPaid)} />
          <LabelValue label="Amount Received" value={formatInr(booking.amountReceived)} />
          <LabelValue label="Total Payment" value={formatInr(totalPayment)} />
          <LabelValue label="Payment Pending" value={formatInr(Math.max(0, paymentPending))} valueClassName="text-[#8D5E12]" />
          <LabelValue
            label="Earnings"
            value={formatInr(earnings)}
            valueClassName={earnings >= 0 ? "text-[#006F57]" : "text-[#B42318]"}
          />
        </div>
      </section>

      <section className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-4">
        <h2 className="text-sm font-heading font-semibold text-[#102A43] mb-3">Documents</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <DocumentCard title="Invoice" uploaded={booking.docs.invoice} icon={<FileText className="h-4 w-4 text-[#009877]" />} />
          <DocumentCard title="ATOL" uploaded={booking.docs.atol} icon={<BadgeCheck className="h-4 w-4 text-[#009877]" />} />
          <DocumentCard title="Customer Passport" uploaded={booking.docs.passport} icon={<IdCard className="h-4 w-4 text-[#009877]" />} />
        </div>
      </section>

      <section className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-4 space-y-3">
        <h2 className="text-sm font-heading font-semibold text-[#102A43]">Child / Infant / Youth</h2>
        <div className="flex items-center gap-3">
          <span className="text-sm text-[#486581]">Is passenger a child/infant/youth?</span>
          <div className="inline-flex rounded-[10px] border border-[#D9E1EA] overflow-hidden">
            <button
              type="button"
              onClick={() => setIsYouthCategory(true)}
              className={`px-3 py-1.5 text-xs font-semibold ${isYouthCategory ? "bg-[#009877] text-white" : "bg-white text-[#486581]"}`}
            >
              Yes
            </button>
            <button
              type="button"
              onClick={() => setIsYouthCategory(false)}
              className={`px-3 py-1.5 text-xs font-semibold ${!isYouthCategory ? "bg-[#009877] text-white" : "bg-white text-[#486581]"}`}
            >
              No
            </button>
          </div>
        </div>

        {isYouthCategory ? (
          <div className="rounded-[10px] border border-dashed border-[#B8C7D9] bg-[#F8FAFC] p-4">
            <p className="text-sm text-[#486581]">Upload age calculator screenshot</p>
            <button
              type="button"
              className="mt-2 inline-flex items-center gap-1.5 rounded-[10px] border border-[#D9E1EA] bg-white px-3 py-1.5 text-xs font-semibold text-[#486581] hover:bg-[#F5F7FA]"
            >
              <Upload className="h-3.5 w-3.5" />
              Upload Screenshot
            </button>
          </div>
        ) : (
          <span className="inline-flex rounded-full border border-[#009877]/35 bg-[#009877]/12 px-2.5 py-1 text-xs font-medium text-[#006F57]">
            Not applicable
          </span>
        )}
      </section>

      <section className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-4 space-y-3">
        <h2 className="text-sm font-heading font-semibold text-[#102A43]">Mode of Payment</h2>
        <select
          value={modeOfPayment}
          onChange={(e) => setModeOfPayment(e.target.value as ModeOfPayment)}
          className="w-full md:w-[260px] rounded-[10px] border border-[#D9E1EA] bg-white px-3 py-2 text-sm text-[#102A43] outline-none focus:border-[#33A1FD]"
        >
          <option value="card">Card</option>
          <option value="bank_transfer">Bank Transfer</option>
          <option value="cash">Cash</option>
        </select>

        {modeOfPayment === "card" || modeOfPayment === "bank_transfer" ? (
          <div className="rounded-[10px] border border-dashed border-[#B8C7D9] bg-[#F8FAFC] p-4">
            <p className="text-sm text-[#486581]">Payment Screenshot (SS)</p>
            <button
              type="button"
              className="mt-2 inline-flex items-center gap-1.5 rounded-[10px] border border-[#D9E1EA] bg-white px-3 py-1.5 text-xs font-semibold text-[#486581] hover:bg-[#F5F7FA]"
            >
              <Upload className="h-3.5 w-3.5" />
              Upload Payment SS
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setDepositType("office")}
                className={`rounded-[10px] px-3 py-1.5 text-xs font-semibold border ${
                  depositType === "office"
                    ? "bg-[#009877] border-[#009877] text-white"
                    : "bg-white border-[#D9E1EA] text-[#486581]"
                }`}
              >
                Office
              </button>
              <button
                type="button"
                onClick={() => setDepositType("home")}
                className={`rounded-[10px] px-3 py-1.5 text-xs font-semibold border ${
                  depositType === "home"
                    ? "bg-[#009877] border-[#009877] text-white"
                    : "bg-white border-[#D9E1EA] text-[#486581]"
                }`}
              >
                Home Deposit
              </button>
            </div>

            {depositType === "home" ? (
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <span className="text-sm text-[#486581]">Receipt received?</span>
                  <div className="inline-flex rounded-[10px] border border-[#D9E1EA] overflow-hidden">
                    <button
                      type="button"
                      onClick={() => setReceiptReceived(true)}
                      className={`px-3 py-1.5 text-xs font-semibold ${receiptReceived ? "bg-[#009877] text-white" : "bg-white text-[#486581]"}`}
                    >
                      Yes
                    </button>
                    <button
                      type="button"
                      onClick={() => setReceiptReceived(false)}
                      className={`px-3 py-1.5 text-xs font-semibold ${!receiptReceived ? "bg-[#B42318] text-white" : "bg-white text-[#486581]"}`}
                    >
                      No
                    </button>
                  </div>
                </div>

                {receiptReceived ? (
                  <div className="space-y-2">
                    <span className="inline-flex rounded-full border border-[#009877]/35 bg-[#009877]/12 px-2.5 py-1 text-xs font-medium text-[#006F57]">
                      Receipt received
                    </span>
                    <div>
                      <button
                        type="button"
                        className="inline-flex items-center gap-1.5 rounded-[10px] border border-[#D9E1EA] bg-white px-3 py-1.5 text-xs font-semibold text-[#486581] hover:bg-[#F5F7FA]"
                      >
                        <Upload className="h-3.5 w-3.5" />
                        Upload Receipt
                      </button>
                    </div>
                  </div>
                ) : (
                  <span className="inline-flex rounded-full border border-[#F1A7A0]/45 bg-[#FDECEC] px-2.5 py-1 text-xs font-medium text-[#B42318]">
                    Receipt not received
                  </span>
                )}
              </div>
            ) : null}
          </div>
        )}
      </section>

      <section className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-4 space-y-3">
        <h2 className="text-sm font-heading font-semibold text-[#102A43]">Refund</h2>
        <div className="flex items-center gap-3">
          <span className="text-sm text-[#486581]">Refund?</span>
          <div className="inline-flex rounded-[10px] border border-[#D9E1EA] overflow-hidden">
            <button
              type="button"
              onClick={() => setIsRefund(true)}
              className={`px-3 py-1.5 text-xs font-semibold ${isRefund ? "bg-[#009877] text-white" : "bg-white text-[#486581]"}`}
            >
              Yes
            </button>
            <button
              type="button"
              onClick={() => setIsRefund(false)}
              className={`px-3 py-1.5 text-xs font-semibold ${!isRefund ? "bg-[#009877] text-white" : "bg-white text-[#486581]"}`}
            >
              No
            </button>
          </div>
        </div>

        {!isRefund ? (
          <span className="inline-flex rounded-full border border-[#009877]/35 bg-[#009877]/12 px-2.5 py-1 text-xs font-medium text-[#006F57]">
            No refund
          </span>
        ) : (
          <div className="space-y-3">
            <span className="inline-flex rounded-full border border-[#B197FC]/40 bg-[#EDE4FF] px-2.5 py-1 text-xs font-medium text-[#5F3DC4]">
              Credit Note
            </span>

            <div className="flex items-center gap-3">
              <span className="text-sm text-[#486581]">Refund received from supplier?</span>
              <div className="inline-flex rounded-[10px] border border-[#D9E1EA] overflow-hidden">
                <button
                  type="button"
                  onClick={() => setRefundReceivedFromSupplier(true)}
                  className={`px-3 py-1.5 text-xs font-semibold ${refundReceivedFromSupplier ? "bg-[#009877] text-white" : "bg-white text-[#486581]"}`}
                >
                  Yes
                </button>
                <button
                  type="button"
                  onClick={() => setRefundReceivedFromSupplier(false)}
                  className={`px-3 py-1.5 text-xs font-semibold ${!refundReceivedFromSupplier ? "bg-[#B42318] text-white" : "bg-white text-[#486581]"}`}
                >
                  No
                </button>
              </div>
            </div>

            {refundReceivedFromSupplier ? (
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <span className="text-sm text-[#486581]">Given to customer?</span>
                  <div className="inline-flex rounded-[10px] border border-[#D9E1EA] overflow-hidden">
                    <button
                      type="button"
                      onClick={() => setGivenToCustomer(true)}
                      className={`px-3 py-1.5 text-xs font-semibold ${givenToCustomer ? "bg-[#009877] text-white" : "bg-white text-[#486581]"}`}
                    >
                      Yes
                    </button>
                    <button
                      type="button"
                      onClick={() => setGivenToCustomer(false)}
                      className={`px-3 py-1.5 text-xs font-semibold ${!givenToCustomer ? "bg-[#B87333] text-white" : "bg-white text-[#486581]"}`}
                    >
                      No
                    </button>
                  </div>
                </div>

                {givenToCustomer ? (
                  <div className="rounded-[10px] border border-dashed border-[#B8C7D9] bg-[#F8FAFC] p-4">
                    <p className="text-sm text-[#486581]">Upload transfer screenshot</p>
                    <button
                      type="button"
                      className="mt-2 inline-flex items-center gap-1.5 rounded-[10px] border border-[#D9E1EA] bg-white px-3 py-1.5 text-xs font-semibold text-[#486581] hover:bg-[#F5F7FA]"
                    >
                      <Upload className="h-3.5 w-3.5" />
                      Upload SS
                    </button>
                  </div>
                ) : (
                  <span className="inline-flex rounded-full border border-[#D4A84F]/40 bg-[#F9DBAF]/35 px-2.5 py-1 text-xs font-medium text-[#8D5E12]">
                    Pending
                  </span>
                )}
              </div>
            ) : (
              <span className="inline-flex rounded-full border border-[#F1A7A0]/45 bg-[#FDECEC] px-2.5 py-1 text-xs font-medium text-[#B42318]">
                Chasing supplier
              </span>
            )}
          </div>
        )}
      </section>

      <section className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-4 space-y-3">
        <h2 className="text-sm font-heading font-semibold text-[#102A43]">Schedule Change</h2>
        <select
          value={scheduleChange}
          onChange={(e) => setScheduleChange(e.target.value as ScheduleChange)}
          className="w-full md:w-[260px] rounded-[10px] border border-[#D9E1EA] bg-white px-3 py-2 text-sm text-[#102A43] outline-none focus:border-[#33A1FD]"
        >
          <option value="none">None</option>
          <option value="minor">Minor</option>
          <option value="major">Major</option>
        </select>

        {scheduleChange === "minor" ? (
          <span className="inline-flex rounded-full border border-[#009877]/35 bg-[#009877]/12 px-2.5 py-1 text-xs font-medium text-[#006F57]">
            Inform customer
          </span>
        ) : null}

        {scheduleChange === "major" ? (
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <span className="text-sm text-[#486581]">Re-issued?</span>
              <div className="inline-flex rounded-[10px] border border-[#D9E1EA] overflow-hidden">
                <button
                  type="button"
                  onClick={() => setIsReissued(true)}
                  className={`px-3 py-1.5 text-xs font-semibold ${isReissued ? "bg-[#009877] text-white" : "bg-white text-[#486581]"}`}
                >
                  Yes
                </button>
                <button
                  type="button"
                  onClick={() => setIsReissued(false)}
                  className={`px-3 py-1.5 text-xs font-semibold ${!isReissued ? "bg-[#5F3DC4] text-white" : "bg-white text-[#486581]"}`}
                >
                  No
                </button>
              </div>
            </div>

            {isReissued ? (
              <span className="inline-flex rounded-full border border-[#009877]/35 bg-[#009877]/12 px-2.5 py-1 text-xs font-medium text-[#006F57]">
                Re-issued
              </span>
            ) : (
              <span className="inline-flex rounded-full border border-[#B197FC]/40 bg-[#EDE4FF] px-2.5 py-1 text-xs font-medium text-[#5F3DC4]">
                Credit Note
              </span>
            )}
          </div>
        ) : null}
      </section>

      <div className="flex justify-end">
        <button
          type="button"
          onClick={() => toast.success("Booking details saved successfully.")}
          className="inline-flex items-center gap-2 bg-[#009877] text-white px-5 py-2.5 rounded-[10px] text-sm font-heading font-semibold hover:bg-[#007B61]"
        >
          Save
        </button>
      </div>
    </div>
  );
}

"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAdminAuth } from "@/context/AdminAuthContext";
import {
  Plane,
  Plus,
  Search,
  Eye,
  FileText,
  BadgeCheck,
  IdCard,
  CheckCircle2,
} from "lucide-react";

type RefundStatus = "none" | "pending" | "credit_note";
type ScheduleChange = "none" | "minor" | "major";

type BookingRow = {
  id: number;
  srNo: string;
  supplier: string;
  invoiceNumber: string;
  pnr: string;
  paxName: string;
  airlineCode: string;
  depDate: string;
  returnDate: string;
  amountPaid: number;
  amountReceived: number;
  refundStatus: RefundStatus;
  scheduleChange: ScheduleChange;
  docs: {
    invoice: boolean;
    atol: boolean;
    passport: boolean;
  };
  createdBy: number;
};

const MOCK_BOOKINGS: BookingRow[] = [
  {
    id: 101,
    srNo: "EF-2401",
    supplier: "Amadeus Hub",
    invoiceNumber: "INV-EF-1001",
    pnr: "Q7K9TP",
    paxName: "Aarav Sharma",
    airlineCode: "AI",
    depDate: "2026-05-10",
    returnDate: "2026-05-18",
    amountPaid: 42500,
    amountReceived: 46800,
    refundStatus: "none",
    scheduleChange: "none",
    docs: { invoice: true, atol: true, passport: true },
    createdBy: 2,
  },
  {
    id: 102,
    srNo: "EF-2402",
    supplier: "Skyline Consolidators",
    invoiceNumber: "INV-EF-1002",
    pnr: "M2R4XZ",
    paxName: "Priya Menon",
    airlineCode: "UK",
    depDate: "2026-05-14",
    returnDate: "2026-05-21",
    amountPaid: 36200,
    amountReceived: 35000,
    refundStatus: "pending",
    scheduleChange: "minor",
    docs: { invoice: true, atol: false, passport: true },
    createdBy: 3,
  },
  {
    id: 103,
    srNo: "EF-2403",
    supplier: "Global Fare Desk",
    invoiceNumber: "INV-EF-1003",
    pnr: "L8D1CN",
    paxName: "Rahul Nair",
    airlineCode: "6E",
    depDate: "2026-05-20",
    returnDate: "2026-05-27",
    amountPaid: 28900,
    amountReceived: 31900,
    refundStatus: "credit_note",
    scheduleChange: "major",
    docs: { invoice: true, atol: true, passport: false },
    createdBy: 2,
  },
  {
    id: 104,
    srNo: "EF-2404",
    supplier: "Amadeus Hub",
    invoiceNumber: "INV-EF-1004",
    pnr: "B4W2RY",
    paxName: "Neha Arora",
    airlineCode: "SG",
    depDate: "2026-06-02",
    returnDate: "2026-06-09",
    amountPaid: 50150,
    amountReceived: 48600,
    refundStatus: "none",
    scheduleChange: "none",
    docs: { invoice: true, atol: false, passport: true },
    createdBy: 4,
  },
  {
    id: 105,
    srNo: "EF-2405",
    supplier: "Skyline Consolidators",
    invoiceNumber: "INV-EF-1005",
    pnr: "T5V8LK",
    paxName: "Kavya Iyer",
    airlineCode: "QR",
    depDate: "2026-06-11",
    returnDate: "2026-06-20",
    amountPaid: 78400,
    amountReceived: 82100,
    refundStatus: "none",
    scheduleChange: "minor",
    docs: { invoice: true, atol: true, passport: true },
    createdBy: 3,
  },
  {
    id: 106,
    srNo: "EF-2406",
    supplier: "Direct Carrier Desk",
    invoiceNumber: "INV-EF-1006",
    pnr: "P9J3FD",
    paxName: "Sanjay Kapoor",
    airlineCode: "EK",
    depDate: "2026-06-16",
    returnDate: "2026-06-26",
    amountPaid: 91500,
    amountReceived: 88000,
    refundStatus: "pending",
    scheduleChange: "major",
    docs: { invoice: true, atol: true, passport: false },
    createdBy: 5,
  },
];

const formatInr = (amount: number) => `INR ${amount.toLocaleString("en-IN")}`;

const formatDate = (dateString: string) =>
  new Date(dateString).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

function statusBadgeClass(status: RefundStatus) {
  if (status === "none") return "bg-[#009877]/12 text-[#006F57] border-[#009877]/35";
  if (status === "pending") return "bg-[#F9DBAF]/35 text-[#8D5E12] border-[#D4A84F]/40";
  return "bg-[#EDE4FF] text-[#5F3DC4] border-[#B197FC]/40";
}

function scheduleBadgeClass(status: ScheduleChange) {
  if (status === "none") return "bg-[#009877]/12 text-[#006F57] border-[#009877]/35";
  if (status === "minor") return "bg-[#F9DBAF]/35 text-[#8D5E12] border-[#D4A84F]/40";
  return "bg-[#FDECEC] text-[#B42318] border-[#F1A7A0]/45";
}

function DocumentStatus({ icon, label, uploaded }: { icon: React.ReactNode; label: string; uploaded: boolean }) {
  return (
    <span
      title={`${label} ${uploaded ? "uploaded" : "missing"}`}
      className={`inline-flex h-7 w-7 items-center justify-center rounded-[8px] border ${
        uploaded
          ? "border-[#009877]/30 bg-[#009877]/10 text-[#009877]"
          : "border-[#D9E1EA] bg-[#F5F7FA] text-[#9AA5B1]"
      }`}
    >
      <span className="relative inline-flex items-center justify-center">
        {icon}
        {uploaded ? <CheckCircle2 className="absolute -right-1.5 -bottom-1.5 h-3.5 w-3.5 text-[#009877] bg-white rounded-full" /> : null}
      </span>
    </span>
  );
}

export default function EasyFlyBookingsPage() {
  const router = useRouter();
  const { adminUser } = useAdminAuth();

  const [search, setSearch] = useState("");
  const [supplierFilter, setSupplierFilter] = useState("all");
  const [airlineFilter, setAirlineFilter] = useState("all");
  const [depFrom, setDepFrom] = useState("");
  const [depTo, setDepTo] = useState("");

  const isAdmin = adminUser?.role === "admin";
  const baseRows = useMemo(() => {
    if (isAdmin) return MOCK_BOOKINGS;
    const isStaff = ["case_processor", "reviewer"].includes(adminUser?.role || "");
    if (!isStaff) return MOCK_BOOKINGS;
    return MOCK_BOOKINGS.filter((booking) => booking.createdBy === adminUser?.id);
  }, [adminUser?.id, adminUser?.role, isAdmin]);

  const supplierOptions = useMemo(
    () => Array.from(new Set(baseRows.map((booking) => booking.supplier))),
    [baseRows],
  );

  const airlineOptions = useMemo(
    () => Array.from(new Set(baseRows.map((booking) => booking.airlineCode))),
    [baseRows],
  );

  const filteredRows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return baseRows.filter((booking) => {
      const matchesSearch =
        !q ||
        booking.paxName.toLowerCase().includes(q) ||
        booking.pnr.toLowerCase().includes(q) ||
        booking.invoiceNumber.toLowerCase().includes(q);

      const matchesSupplier = supplierFilter === "all" || booking.supplier === supplierFilter;
      const matchesAirline = airlineFilter === "all" || booking.airlineCode === airlineFilter;

      const dep = booking.depDate;
      const matchesFrom = !depFrom || dep >= depFrom;
      const matchesTo = !depTo || dep <= depTo;

      return matchesSearch && matchesSupplier && matchesAirline && matchesFrom && matchesTo;
    });
  }, [airlineFilter, baseRows, depFrom, depTo, search, supplierFilter]);

  const stats = useMemo(() => {
    const totalBookings = filteredRows.length;
    const amountPaid = filteredRows.reduce((sum, booking) => sum + booking.amountPaid, 0);
    const amountReceived = filteredRows.reduce((sum, booking) => sum + booking.amountReceived, 0);
    const pendingPayments = filteredRows.reduce(
      (sum, booking) => sum + Math.max(0, booking.amountPaid - booking.amountReceived),
      0,
    );
    const earnings = filteredRows.reduce(
      (sum, booking) => sum + Math.max(0, booking.amountReceived - booking.amountPaid),
      0,
    );

    return { totalBookings, amountPaid, amountReceived, pendingPayments, earnings };
  }, [filteredRows]);

  return (
    <div className="space-y-4 font-body max-w-[1500px] mx-auto">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-[26px] leading-tight font-heading font-semibold text-[#102A43] inline-flex items-center gap-2">
            <Plane className="w-6 h-6 text-[#009877]" />
            EasyFly Bookings
          </h1>
          <p className="mt-1 text-sm text-[#627D98]">Manage all flight bookings</p>
        </div>
        <button
          type="button"
          className="inline-flex items-center gap-2 bg-[#009877] text-white px-4 py-2 rounded-[10px] text-sm font-heading font-semibold hover:bg-[#007B61]"
        >
          <Plus className="h-4 w-4" />
          Add Booking
        </button>
      </div>

      <div className={`grid gap-3 ${isAdmin ? "grid-cols-1 sm:grid-cols-2 xl:grid-cols-5" : "grid-cols-1"}`}>
        <div className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-4">
          <p className="text-xs text-[#627D98]">Total Bookings</p>
          <p className="mt-1 text-lg font-heading font-semibold text-[#102A43]">{stats.totalBookings}</p>
        </div>

        {isAdmin ? (
          <>
            <div className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-4">
              <p className="text-xs text-[#627D98]">Amount Paid</p>
              <p className="mt-1 text-lg font-heading font-semibold text-[#102A43]">{formatInr(stats.amountPaid)}</p>
            </div>
            <div className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-4">
              <p className="text-xs text-[#627D98]">Amount Received</p>
              <p className="mt-1 text-lg font-heading font-semibold text-[#102A43]">{formatInr(stats.amountReceived)}</p>
            </div>
            <div className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-4">
              <p className="text-xs text-[#627D98]">Pending Payments</p>
              <p className="mt-1 text-lg font-heading font-semibold text-[#102A43]">{formatInr(stats.pendingPayments)}</p>
            </div>
            <div className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-4">
              <p className="text-xs text-[#627D98]">Earnings</p>
              <p className="mt-1 text-lg font-heading font-semibold text-[#102A43]">{formatInr(stats.earnings)}</p>
            </div>
          </>
        ) : null}
      </div>

      <div className="bg-white rounded-[12px] border-[0.5px] border-[#D9E1EA] p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-3">
          <label className="xl:col-span-2 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#7B8794]" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search pax name, PNR, invoice number"
              className="w-full rounded-[10px] border border-[#D9E1EA] bg-white pl-9 pr-3 py-2 text-sm text-[#102A43] outline-none focus:border-[#33A1FD]"
            />
          </label>

          <select
            value={supplierFilter}
            onChange={(e) => setSupplierFilter(e.target.value)}
            className="rounded-[10px] border border-[#D9E1EA] bg-white px-3 py-2 text-sm text-[#102A43] outline-none focus:border-[#33A1FD]"
          >
            <option value="all">All Suppliers</option>
            {supplierOptions.map((supplier) => (
              <option key={supplier} value={supplier}>
                {supplier}
              </option>
            ))}
          </select>

          <select
            value={airlineFilter}
            onChange={(e) => setAirlineFilter(e.target.value)}
            className="rounded-[10px] border border-[#D9E1EA] bg-white px-3 py-2 text-sm text-[#102A43] outline-none focus:border-[#33A1FD]"
          >
            <option value="all">All Airlines</option>
            {airlineOptions.map((airline) => (
              <option key={airline} value={airline}>
                {airline}
              </option>
            ))}
          </select>

          <div className="grid grid-cols-2 gap-2 xl:col-span-1">
            <input
              type="date"
              value={depFrom}
              onChange={(e) => setDepFrom(e.target.value)}
              className="rounded-[10px] border border-[#D9E1EA] bg-white px-3 py-2 text-sm text-[#102A43] outline-none focus:border-[#33A1FD]"
              title="Departure from"
            />
            <input
              type="date"
              value={depTo}
              onChange={(e) => setDepTo(e.target.value)}
              className="rounded-[10px] border border-[#D9E1EA] bg-white px-3 py-2 text-sm text-[#102A43] outline-none focus:border-[#33A1FD]"
              title="Departure to"
            />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-[12px] border-[0.5px] border-[#D9E1EA] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1700px] text-sm">
            <thead className="bg-[#F5F7FA] text-[#486581]">
              <tr>
                <th className="px-3 py-2.5 text-left font-semibold">SR No.</th>
                <th className="px-3 py-2.5 text-left font-semibold">Supplier</th>
                <th className="px-3 py-2.5 text-left font-semibold">Invoice Number</th>
                <th className="px-3 py-2.5 text-left font-semibold">PNR</th>
                <th className="px-3 py-2.5 text-left font-semibold">Pax Name</th>
                <th className="px-3 py-2.5 text-left font-semibold">Airline Code</th>
                <th className="px-3 py-2.5 text-left font-semibold">Dep Date</th>
                <th className="px-3 py-2.5 text-left font-semibold">Return Date</th>
                <th className="px-3 py-2.5 text-left font-semibold">Amount Paid</th>
                <th className="px-3 py-2.5 text-left font-semibold">Amount Received</th>
                <th className="px-3 py-2.5 text-left font-semibold">Total Payment</th>
                <th className="px-3 py-2.5 text-left font-semibold">Payment Pending</th>
                <th className="px-3 py-2.5 text-left font-semibold">Earnings</th>
                <th className="px-3 py-2.5 text-left font-semibold">Refund</th>
                <th className="px-3 py-2.5 text-left font-semibold">Schedule Change</th>
                <th className="px-3 py-2.5 text-left font-semibold">Documents</th>
                <th className="px-3 py-2.5 text-left font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E5EAF0] text-[#334E68]">
              {filteredRows.map((booking) => {
                const paymentPending = Math.max(0, booking.amountPaid - booking.amountReceived);
                const earnings = Math.max(0, booking.amountReceived - booking.amountPaid);
                const totalPayment = booking.amountPaid + booking.amountReceived;

                return (
                  <tr
                    key={booking.id}
                    onClick={() => router.push(`/admin/easyfly/${booking.id}`)}
                    className="cursor-pointer hover:bg-[#F8FCFF]"
                  >
                    <td className="px-3 py-2.5">{booking.srNo}</td>
                    <td className="px-3 py-2.5">{booking.supplier}</td>
                    <td className="px-3 py-2.5">{booking.invoiceNumber}</td>
                    <td className="px-3 py-2.5 font-medium text-[#102A43]">{booking.pnr}</td>
                    <td className="px-3 py-2.5">{booking.paxName}</td>
                    <td className="px-3 py-2.5">{booking.airlineCode}</td>
                    <td className="px-3 py-2.5">{formatDate(booking.depDate)}</td>
                    <td className="px-3 py-2.5">{formatDate(booking.returnDate)}</td>
                    <td className="px-3 py-2.5">{formatInr(booking.amountPaid)}</td>
                    <td className="px-3 py-2.5">{formatInr(booking.amountReceived)}</td>
                    <td className="px-3 py-2.5">{formatInr(totalPayment)}</td>
                    <td className="px-3 py-2.5 text-[#8D5E12]">{formatInr(paymentPending)}</td>
                    <td className="px-3 py-2.5 text-[#006F57]">{formatInr(earnings)}</td>
                    <td className="px-3 py-2.5">
                      <span className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${statusBadgeClass(booking.refundStatus)}`}>
                        {booking.refundStatus === "none"
                          ? "None"
                          : booking.refundStatus === "pending"
                            ? "Pending"
                            : "Credit Note"}
                      </span>
                    </td>
                    <td className="px-3 py-2.5">
                      <span className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${scheduleBadgeClass(booking.scheduleChange)}`}>
                        {booking.scheduleChange === "none"
                          ? "None"
                          : booking.scheduleChange === "minor"
                            ? "Minor"
                            : "Major"}
                      </span>
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-1.5">
                        <DocumentStatus icon={<FileText className="h-3.5 w-3.5" />} label="Invoice" uploaded={booking.docs.invoice} />
                        <DocumentStatus icon={<BadgeCheck className="h-3.5 w-3.5" />} label="ATOL" uploaded={booking.docs.atol} />
                        <DocumentStatus icon={<IdCard className="h-3.5 w-3.5" />} label="Passport" uploaded={booking.docs.passport} />
                      </div>
                    </td>
                    <td className="px-3 py-2.5">
                      <Link
                        href={`/admin/easyfly/${booking.id}`}
                        onClick={(event) => event.stopPropagation()}
                        className="inline-flex h-8 w-8 items-center justify-center rounded-[8px] border border-[#D9E1EA] text-[#486581] hover:bg-[#F5F7FA]"
                        aria-label={`View booking ${booking.pnr}`}
                      >
                        <Eye className="h-4 w-4" />
                      </Link>
                    </td>
                  </tr>
                );
              })}

              {filteredRows.length === 0 ? (
                <tr>
                  <td colSpan={17} className="px-3 py-8 text-center text-sm text-[#7B8794]">
                    No bookings match the selected filters.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useAdminAuth } from "@/context/AdminAuthContext";
import { CalendarClock, Search, Eye } from "lucide-react";

type RefundStatus = "none" | "pending" | "credit_note";
type ScheduleChange = "none" | "minor" | "major";

type BookingRow = {
  id: number;
  srNo: string;
  supplier: string;
  invoiceNumber: string;
  pnr: string;
  paxName: string;
  airlineCode: string;
  depDate: string;
  returnDate: string;
  amountPaid: number;
  amountReceived: number;
  refundStatus: RefundStatus;
  scheduleChange: ScheduleChange;
  docs: {
    invoice: boolean;
    atol: boolean;
    passport: boolean;
  };
  createdBy: number;
};

const MOCK_BOOKINGS: BookingRow[] = [
  {
    id: 101,
    srNo: "EF-2401",
    supplier: "Amadeus Hub",
    invoiceNumber: "INV-EF-1001",
    pnr: "Q7K9TP",
    paxName: "Aarav Sharma",
    airlineCode: "AI",
    depDate: "2026-05-10",
    returnDate: "2026-05-18",
    amountPaid: 42500,
    amountReceived: 46800,
    refundStatus: "none",
    scheduleChange: "none",
    docs: { invoice: true, atol: true, passport: true },
    createdBy: 2,
  },
  {
    id: 102,
    srNo: "EF-2402",
    supplier: "Skyline Consolidators",
    invoiceNumber: "INV-EF-1002",
    pnr: "M2R4XZ",
    paxName: "Priya Menon",
    airlineCode: "UK",
    depDate: "2026-05-14",
    returnDate: "2026-05-21",
    amountPaid: 36200,
    amountReceived: 35000,
    refundStatus: "pending",
    scheduleChange: "minor",
    docs: { invoice: true, atol: false, passport: true },
    createdBy: 3,
  },
  {
    id: 103,
    srNo: "EF-2403",
    supplier: "Global Fare Desk",
    invoiceNumber: "INV-EF-1003",
    pnr: "L8D1CN",
    paxName: "Rahul Nair",
    airlineCode: "6E",
    depDate: "2026-05-20",
    returnDate: "2026-05-27",
    amountPaid: 28900,
    amountReceived: 31900,
    refundStatus: "credit_note",
    scheduleChange: "major",
    docs: { invoice: true, atol: true, passport: false },
    createdBy: 2,
  },
  {
    id: 104,
    srNo: "EF-2404",
    supplier: "Amadeus Hub",
    invoiceNumber: "INV-EF-1004",
    pnr: "B4W2RY",
    paxName: "Neha Arora",
    airlineCode: "SG",
    depDate: "2026-06-02",
    returnDate: "2026-06-09",
    amountPaid: 50150,
    amountReceived: 48600,
    refundStatus: "none",
    scheduleChange: "none",
    docs: { invoice: true, atol: false, passport: true },
    createdBy: 4,
  },
  {
    id: 105,
    srNo: "EF-2405",
    supplier: "Skyline Consolidators",
    invoiceNumber: "INV-EF-1005",
    pnr: "T5V8LK",
    paxName: "Kavya Iyer",
    airlineCode: "QR",
    depDate: "2026-06-11",
    returnDate: "2026-06-20",
    amountPaid: 78400,
    amountReceived: 82100,
    refundStatus: "none",
    scheduleChange: "minor",
    docs: { invoice: true, atol: true, passport: true },
    createdBy: 3,
  },
  {
    id: 106,
    srNo: "EF-2406",
    supplier: "Direct Carrier Desk",
    invoiceNumber: "INV-EF-1006",
    pnr: "P9J3FD",
    paxName: "Sanjay Kapoor",
    airlineCode: "EK",
    depDate: "2026-06-16",
    returnDate: "2026-06-26",
    amountPaid: 91500,
    amountReceived: 88000,
    refundStatus: "pending",
    scheduleChange: "major",
    docs: { invoice: true, atol: true, passport: false },
    createdBy: 5,
  },
];

const formatDate = (dateString: string) =>
  new Date(dateString).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

const REISSUED_BY_BOOKING_ID: Record<number, boolean> = {
  103: false,
  106: true,
};

function getIsReissued(bookingId: number) {
  return Boolean(REISSUED_BY_BOOKING_ID[bookingId]);
}

function SectionTable({
  rows,
  type,
}: {
  rows: BookingRow[];
  type: "major" | "minor";
}) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[960px] text-sm">
        <thead className="bg-[#F5F7FA] text-[#486581]">
          <tr>
            <th className="px-3 py-2.5 text-left font-semibold">SR No.</th>
            <th className="px-3 py-2.5 text-left font-semibold">Pax Name</th>
            <th className="px-3 py-2.5 text-left font-semibold">PNR</th>
            <th className="px-3 py-2.5 text-left font-semibold">Airline</th>
            <th className="px-3 py-2.5 text-left font-semibold">Dep Date</th>
            <th className="px-3 py-2.5 text-left font-semibold">Supplier</th>
            <th className="px-3 py-2.5 text-left font-semibold">Re-issued?</th>
            <th className="px-3 py-2.5 text-left font-semibold">Action Needed</th>
            <th className="px-3 py-2.5 text-left font-semibold">View</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#E5EAF0] text-[#334E68]">
          {rows.map((booking) => {
            const reissued = getIsReissued(booking.id);
            const showCreditNote = type === "major" && !reissued;
            return (
              <tr key={booking.id} className="hover:bg-[#F8FCFF]">
                <td className="px-3 py-2.5">{booking.srNo}</td>
                <td className="px-3 py-2.5">{booking.paxName}</td>
                <td className="px-3 py-2.5 font-medium text-[#102A43]">{booking.pnr}</td>
                <td className="px-3 py-2.5">{booking.airlineCode}</td>
                <td className="px-3 py-2.5">{formatDate(booking.depDate)}</td>
                <td className="px-3 py-2.5">{booking.supplier}</td>
                <td className="px-3 py-2.5">
                  <span
                    className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${
                      reissued
                        ? "bg-[#009877]/12 text-[#006F57] border-[#009877]/35"
                        : "bg-[#FDECEC] text-[#B42318] border-[#F1A7A0]/45"
                    }`}
                  >
                    {reissued ? "Yes" : "No"}
                  </span>
                </td>
                <td className="px-3 py-2.5">
                  {type === "major" ? (
                    <span
                      className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${
                        showCreditNote
                          ? "bg-[#FDECEC] text-[#B42318] border-[#F1A7A0]/45"
                          : "bg-[#009877]/12 text-[#006F57] border-[#009877]/35"
                      }`}
                    >
                      {showCreditNote ? "Credit Note" : "Resolved"}
                    </span>
                  ) : (
                    <span className="inline-flex rounded-full border px-2.5 py-1 text-xs font-medium bg-[#F9DBAF]/35 text-[#8D5E12] border-[#D4A84F]/40">
                      Inform Customer
                    </span>
                  )}
                </td>
                <td className="px-3 py-2.5">
                  <Link
                    href={`/admin/easyfly/${booking.id}`}
                    className="inline-flex h-8 w-8 items-center justify-center rounded-[8px] border border-[#D9E1EA] text-[#486581] hover:bg-[#F5F7FA]"
                    aria-label={`View booking ${booking.pnr}`}
                  >
                    <Eye className="h-4 w-4" />
                  </Link>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export default function EasyFlySchedulePage() {
  const { adminUser } = useAdminAuth();

  const [search, setSearch] = useState("");
  const [changeFilter, setChangeFilter] = useState<"all" | "minor" | "major">("all");
  const [supplierFilter, setSupplierFilter] = useState("all");

  const roleFiltered = useMemo(() => {
    const isAdmin = adminUser?.role === "admin";
    if (isAdmin) return MOCK_BOOKINGS;
    const isStaff = ["case_processor", "reviewer"].includes(adminUser?.role || "");
    if (!isStaff) return MOCK_BOOKINGS;
    return MOCK_BOOKINGS.filter((booking) => booking.createdBy === adminUser?.id);
  }, [adminUser?.id, adminUser?.role]);

  const scheduleRows = useMemo(
    () => roleFiltered.filter((booking) => booking.scheduleChange !== "none"),
    [roleFiltered],
  );

  const supplierOptions = useMemo(
    () => Array.from(new Set(scheduleRows.map((booking) => booking.supplier))),
    [scheduleRows],
  );

  const filteredRows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return scheduleRows.filter((booking) => {
      const matchesSearch =
        !q || booking.paxName.toLowerCase().includes(q) || booking.pnr.toLowerCase().includes(q);
      const matchesType =
        changeFilter === "all" || booking.scheduleChange === changeFilter;
      const matchesSupplier = supplierFilter === "all" || booking.supplier === supplierFilter;
      return matchesSearch && matchesType && matchesSupplier;
    });
  }, [changeFilter, scheduleRows, search, supplierFilter]);

  const majorRows = useMemo(
    () => filteredRows.filter((booking) => booking.scheduleChange === "major"),
    [filteredRows],
  );
  const minorRows = useMemo(
    () => filteredRows.filter((booking) => booking.scheduleChange === "minor"),
    [filteredRows],
  );

  const majorCount = scheduleRows.filter((booking) => booking.scheduleChange === "major").length;
  const minorCount = scheduleRows.filter((booking) => booking.scheduleChange === "minor").length;

  if (scheduleRows.length === 0) {
    return (
      <div className="font-body max-w-[1200px] mx-auto">
        <div className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-10 text-center">
          <CalendarClock className="w-9 h-9 text-[#627D98] mx-auto" />
          <p className="mt-3 text-base font-heading font-semibold text-[#102A43]">No schedule changes found</p>
          <p className="mt-1 text-sm text-[#627D98]">All current bookings are stable.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 font-body max-w-[1400px] mx-auto">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-[26px] leading-tight font-heading font-semibold text-[#102A43] inline-flex items-center gap-2">
            <CalendarClock className="w-6 h-6 text-[#009877]" />
            Schedule Changes
          </h1>
          <p className="mt-1 text-sm text-[#627D98]">Bookings with flight schedule changes</p>
        </div>

        <div className="flex items-center gap-2">
          <span className="inline-flex rounded-full border border-[#009877]/35 bg-[#009877]/12 px-3 py-1 text-xs font-semibold text-[#006F57]">
            Minor: {minorCount}
          </span>
          <span className="inline-flex rounded-full border border-[#F1A7A0]/45 bg-[#FDECEC] px-3 py-1 text-xs font-semibold text-[#B42318]">
            Major: {majorCount}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-4">
          <p className="text-xs text-[#627D98]">Total Schedule Changes</p>
          <p className="mt-1 text-lg font-heading font-semibold text-[#102A43]">{scheduleRows.length}</p>
        </div>
        <div className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-4">
          <p className="text-xs text-[#627D98]">Minor Changes</p>
          <p className="mt-1 text-lg font-heading font-semibold text-[#8D5E12]">{minorCount}</p>
        </div>
        <div className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-4">
          <p className="text-xs text-[#627D98]">Major Changes</p>
          <p className="mt-1 text-lg font-heading font-semibold text-[#B42318]">{majorCount}</p>
        </div>
      </div>

      <div className="bg-white rounded-[12px] border-[0.5px] border-[#D9E1EA] p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <label className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#7B8794]" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search pax name, PNR"
              className="w-full rounded-[10px] border border-[#D9E1EA] bg-white pl-9 pr-3 py-2 text-sm text-[#102A43] outline-none focus:border-[#33A1FD]"
            />
          </label>

          <select
            value={changeFilter}
            onChange={(e) => setChangeFilter(e.target.value as "all" | "minor" | "major")}
            className="rounded-[10px] border border-[#D9E1EA] bg-white px-3 py-2 text-sm text-[#102A43] outline-none focus:border-[#33A1FD]"
          >
            <option value="all">All</option>
            <option value="minor">Minor</option>
            <option value="major">Major</option>
          </select>

          <select
            value={supplierFilter}
            onChange={(e) => setSupplierFilter(e.target.value)}
            className="rounded-[10px] border border-[#D9E1EA] bg-white px-3 py-2 text-sm text-[#102A43] outline-none focus:border-[#33A1FD]"
          >
            <option value="all">All Suppliers</option>
            {supplierOptions.map((supplier) => (
              <option key={supplier} value={supplier}>
                {supplier}
              </option>
            ))}
          </select>
        </div>
      </div>

      <section className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] overflow-hidden border-l-4 border-l-[#B42318]">
        <div className="px-4 py-3 border-b border-[#E5EAF0] flex items-center justify-between">
          <h2 className="text-sm font-heading font-semibold text-[#102A43]">Major Changes</h2>
          <span className="text-xs text-[#B42318] font-semibold">{majorRows.length} booking(s)</span>
        </div>
        {majorRows.length > 0 ? (
          <SectionTable rows={majorRows} type="major" />
        ) : (
          <div className="px-4 py-8 text-center text-sm text-[#7B8794]">No major changes for current filters.</div>
        )}
      </section>

      <section className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] overflow-hidden border-l-4 border-l-[#D4A84F]">
        <div className="px-4 py-3 border-b border-[#E5EAF0] flex items-center justify-between">
          <h2 className="text-sm font-heading font-semibold text-[#102A43]">Minor Changes</h2>
          <span className="text-xs text-[#8D5E12] font-semibold">{minorRows.length} booking(s)</span>
        </div>
        {minorRows.length > 0 ? (
          <SectionTable rows={minorRows} type="minor" />
        ) : (
          <div className="px-4 py-8 text-center text-sm text-[#7B8794]">No minor changes for current filters.</div>
        )}
      </section>
    </div>
  );
}

// "use client";

// import { useState } from "react";
// import { Sidebar } from "@/components/console/Sidebar";
// import { TopHeader } from "@/components/console/TopHeader";
// import { motion, AnimatePresence } from "framer-motion";
// import { usePathname, useRouter } from "next/navigation";
// import { ConsoleProvider } from "@/components/console/ConsoleContext";
// import { Toaster } from "react-hot-toast";
// import { AdminAuthProvider, useAdminAuth } from "@/context/AdminAuthContext";
// import { useEffect } from "react";

// export default function ConsoleLayout({
//   children,
// }: {
//   children: React.ReactNode;
// }) {
//   return (
//     <AdminAuthProvider>
//       <AdminLayoutContent>{children}</AdminLayoutContent>
//     </AdminAuthProvider>
//   );
// }

// function AdminLayoutContent({ children }: { children: React.ReactNode }) {
//   const [collapsed, setCollapsed] = useState(false);
//   const pathname = usePathname();
//   const router = useRouter();
//   const { isAuthenticated, isBootstrapped, logout, adminUser } = useAdminAuth();
//   const isPublicAdminAuthRoute = pathname === "/admin/login" || pathname === "/admin/reset-password";

//   useEffect(() => {
//     if (!isBootstrapped) {
//       return;
//     }
//     if (!isAuthenticated && !isPublicAdminAuthRoute) {
//       router.replace("/admin/login");
//     }
//     if (isAuthenticated && isPublicAdminAuthRoute) {
//       router.replace("/admin");
//     }
//   }, [isAuthenticated, isBootstrapped, isPublicAdminAuthRoute, router]);

//   useEffect(() => {
//     if (!adminUser || isPublicAdminAuthRoute || pathname === "/admin") {
//       return;
//     }

//     const role = adminUser.role;
//     if (role === "admin") {
//       return;
//     }

//     const roleAccess: Record<string, string[]> = {
//       ops_manager: ["/admin", "/admin/kanban", "/admin/reports", "/admin/alerts", "/admin/team", "/admin/settings"],
//       case_processor: ["/admin", "/admin/kanban"],
//       reviewer: ["/admin", "/admin/kanban", "/admin/reports"],
//       support_agent: ["/admin"],
//     };

//     const allowedRoots = roleAccess[role] || ["/admin"];
//     const hasAccess = allowedRoots.some((root) => pathname === root || (root !== "/admin" && pathname.startsWith(root)));
//     if (!hasAccess) {
//       router.replace("/admin");
//     }
//   }, [adminUser, isPublicAdminAuthRoute, pathname, router]);

//  // In AdminLayoutContent, replace the isBootstrapped check block:

// if (!isBootstrapped) {
//   return (
//     <div className="flex min-h-screen items-center justify-center bg-[#F5F7FA]">
//       <div className="flex flex-col items-center gap-3">
//         <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#D9E1EA] border-t-[#009877]" />
//         <p className="text-sm text-[#627D98] font-medium">Loading...</p>
//       </div>
//     </div>
//   );
// }

// // ADD THIS — prevents the dashboard flash while redirect is in-flight
// if (!isAuthenticated && !isPublicAdminAuthRoute) {
//   return null; // redirect is about to happen, render nothing
// }

//   if (isPublicAdminAuthRoute) {
//     return (
//       <>
//         {children}
//         <Toaster
//           position="top-right"
//           toastOptions={{
//             style: { background: "#FFFFFF", color: "#0F172A", border: "0.5px solid #D9E1EA", borderRadius: "12px" },
//           }}
//         />
//       </>
//     );
//   }

//   return (
//     <ConsoleProvider>
//       <div className="flex h-screen bg-[#F5F7FA] overflow-hidden text-slate-900">
//         <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />

//         <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
//           <TopHeader />

//           <main className="relative flex-1 overflow-y-auto p-4 md:p-6 lg:p-7">
//             <motion.div
//               aria-hidden
//               className="pointer-events-none absolute -top-20 -right-16 h-52 w-52 rounded-full bg-[#33A1FD]/10 blur-3xl"
//               animate={{ x: [0, -14, 0], y: [0, 10, 0], opacity: [0.35, 0.5, 0.35] }}
//               transition={{ duration: 11, repeat: Infinity, ease: "easeInOut" }}
//             />
//             <motion.div
//               aria-hidden
//               className="pointer-events-none absolute top-1/3 -left-20 h-44 w-44 rounded-full bg-[#009877]/10 blur-3xl"
//               animate={{ x: [0, 12, 0], y: [0, -8, 0], opacity: [0.25, 0.4, 0.25] }}
//               transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
//             />
//             <AnimatePresence mode="wait">
//               <motion.div
//                 key={pathname}
//                 initial={{ opacity: 0, y: 10 }}
//                 animate={{ opacity: 1, y: 0 }}
//                 exit={{ opacity: 0, y: -10 }}
//                 transition={{ duration: 0.24, ease: "easeOut" }}
//                 className="relative h-full"
//               >
//                 {children}
//               </motion.div>
//             </AnimatePresence>
//           </main>
//         </div>
//       </div>

//       <Toaster
//         position="top-right"
//         toastOptions={{
//           style: { background: "#FFFFFF", color: "#0F172A", border: "0.5px solid #D9E1EA", borderRadius: "12px" },
//         }}
//       />
//     </ConsoleProvider>
//   );
// }




"use client";

import { useState, useEffect } from "react";
import { Sidebar } from "@/components/console/Sidebar";
import { TopHeader } from "@/components/console/TopHeader";
import { motion, AnimatePresence } from "framer-motion";
import { usePathname, useRouter } from "next/navigation";
import { ConsoleProvider } from "@/components/console/ConsoleContext";
import { Toaster } from "react-hot-toast";
import { AdminAuthProvider, useAdminAuth } from "@/context/AdminAuthContext";

export default function ConsoleLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <AdminAuthProvider>
      <AdminLayoutContent>{children}</AdminLayoutContent>
    </AdminAuthProvider>
  );
}

function AdminLayoutContent({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [accessChecked, setAccessChecked] = useState(false);
  const pathname = usePathname();
  const router = useRouter();
  const { isAuthenticated, isBootstrapped, logout, adminUser } = useAdminAuth();
  const isPublicAdminAuthRoute = pathname === "/admin/login" || pathname === "/admin/reset-password";

  useEffect(() => {
    if (!isBootstrapped) return;
    if (!isAuthenticated && !isPublicAdminAuthRoute) {
      router.replace("/admin/login");
    }
    if (isAuthenticated && isPublicAdminAuthRoute) {
      router.replace("/admin");
    }
  }, [isAuthenticated, isBootstrapped, isPublicAdminAuthRoute, router]);

  useEffect(() => {
    if (!adminUser || isPublicAdminAuthRoute) {
      setAccessChecked(true);
      return;
    }

    if (pathname === "/admin") {
      setAccessChecked(true);
      return;
    }

    const role = adminUser.role;
    const scope = (adminUser as any).access_scope ?? "all";

    if (role === "admin") {
      setAccessChecked(true);
      return;
    }

    const roleAccess: Record<string, string[]> = {
      ops_manager: ["/admin", "/admin/kanban", "/admin/reports", "/admin/alerts", "/admin/team", "/admin/settings", "/admin/easyfly"],
      case_processor: ["/admin", "/admin/kanban", "/admin/easyfly"],
      reviewer: ["/admin", "/admin/kanban", "/admin/reports", "/admin/easyfly"],
      support_agent: ["/admin"],
    };

    let allowedRoots = roleAccess[role] || ["/admin"];

    if (scope === "easyfly_only") {
      allowedRoots = ["/admin/easyfly"];
    } else if (scope === "exclude_easyfly") {
      allowedRoots = allowedRoots.filter((r) => !r.startsWith("/admin/easyfly"));
    }

    const hasAccess = allowedRoots.some(
      (root) => pathname === root || (root !== "/admin" && pathname.startsWith(root))
    );

    if (!hasAccess) {
      router.replace("/admin");
      // don't set accessChecked — keep showing spinner until redirect completes
    } else {
      setAccessChecked(true);
    }
  }, [adminUser, isPublicAdminAuthRoute, pathname, router]);

  if (!isBootstrapped) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F5F7FA]">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#D9E1EA] border-t-[#009877]" />
          <p className="text-sm text-[#627D98] font-medium">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated && !isPublicAdminAuthRoute) {
    return null;
  }

  // Block render until access check completes — prevents flash of unauthorized page
  if (!accessChecked && !isPublicAdminAuthRoute) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F5F7FA]">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#D9E1EA] border-t-[#009877]" />
      </div>
    );
  }

  if (isPublicAdminAuthRoute) {
    return (
      <>
        {children}
        <Toaster
          position="top-right"
          toastOptions={{
            style: { background: "#FFFFFF", color: "#0F172A", border: "0.5px solid #D9E1EA", borderRadius: "12px" },
          }}
        />
      </>
    );
  }

  return (
    <ConsoleProvider>
      <div className="flex h-screen bg-[#F5F7FA] overflow-hidden text-slate-900">
        <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />

        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <TopHeader />

          <main className="relative flex-1 overflow-y-auto p-4 md:p-6 lg:p-7">
            <motion.div
              aria-hidden
              className="pointer-events-none absolute -top-20 -right-16 h-52 w-52 rounded-full bg-[#33A1FD]/10 blur-3xl"
              animate={{ x: [0, -14, 0], y: [0, 10, 0], opacity: [0.35, 0.5, 0.35] }}
              transition={{ duration: 11, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.div
              aria-hidden
              className="pointer-events-none absolute top-1/3 -left-20 h-44 w-44 rounded-full bg-[#009877]/10 blur-3xl"
              animate={{ x: [0, 12, 0], y: [0, -8, 0], opacity: [0.25, 0.4, 0.25] }}
              transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
            />
            <AnimatePresence mode="wait">
              <motion.div
                key={pathname}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.24, ease: "easeOut" }}
                className="relative h-full"
              >
                {children}
              </motion.div>
            </AnimatePresence>
          </main>
        </div>
      </div>

      <Toaster
        position="top-right"
        toastOptions={{
          style: { background: "#FFFFFF", color: "#0F172A", border: "0.5px solid #D9E1EA", borderRadius: "12px" },
        }}
      />
    </ConsoleProvider>
  );
}
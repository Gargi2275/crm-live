"use client";

import { useEffect, useMemo, useState } from "react";
import { StatCard } from "@/components/ui/console/StatCard";
import {
  Users,
  Briefcase,
  IndianRupee,
  Clock,
  SearchCheck,
  Banknote,
  AlertTriangle,
  ShieldCheck,
  Workflow,
  TrendingUp,
  Target,
  RefreshCw,
  Shuffle,
  UserCog,
  UserRoundCog,
} from "lucide-react";
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Line,
  Bar,
  ComposedChart,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import { useAdminAuth } from "@/context/AdminAuthContext";
import {
  adminDirectAssignTask,
  assignAdminTask,
  autoAssignAdminTasks,
  getAdminDashboardOverview,
  getStaffPerformanceBadge,
  listAdminApplications,
  listAdminTasks,
  patchAdminTask,
  patchAdminApplication,
  type AdminApplication,
  type AdminDashboardOverview,
  type AdminTaskItem,
} from "@/lib/admin-auth";
import toast from "react-hot-toast";
import { useRouter } from "next/navigation";

export default function ConsoleDashboard() {
  const router = useRouter();
  const { adminUser } = useAdminAuth();
  const [period, setPeriod] = useState<"Daily" | "Weekly" | "Monthly">("Daily");
  const [dashboardData, setDashboardData] = useState<AdminDashboardOverview | null>(null);
  const [applications, setApplications] = useState<AdminApplication[]>([]);
  const [taskItems, setTaskItems] = useState<AdminTaskItem[]>([]);
  const [taskSelections, setTaskSelections] = useState<Record<number, string>>({});
  const [taskActionLoading, setTaskActionLoading] = useState<number | "auto" | null>(null);
  const [staffBadge, setStaffBadge] = useState<string | null>(null);
  const userRole = adminUser?.role;
  const roleLabelMap: Record<string, string> = {
    admin: "Admin",
    ops_manager: "Operations Manager",
    case_processor: "Case Processor",
    reviewer: "Reviewer",
    support_agent: "Support Agent",
  };
  const roleLabel = userRole ? roleLabelMap[userRole] || userRole : "Staff";
  const isFounderView = userRole === "admin";
  const isOpsView = userRole === "ops_manager";
  const isStaffView = userRole === "case_processor" || userRole === "reviewer" || userRole === "support_agent";
  const chartColors = ["#009877", "#33A1FD", "#B87333", "#DCE7F3"];
const [loading, setLoading] = useState(true);


  const loadDashboard = async () => {
  setLoading(true);
  try {
    const shouldLoadTasks = isFounderView || isOpsView;
    const [payload, appPayload, taskPayload] = await Promise.all([
      getAdminDashboardOverview(),
      listAdminApplications(),
      shouldLoadTasks
        ? listAdminTasks({ limit: 500 })
        : isStaffView && adminUser?.id
          ? listAdminTasks({ limit: 100, assignedStaffId: adminUser.id })
          : Promise.resolve([] as AdminTaskItem[]),
    ]);
    setDashboardData(payload);
    setApplications(appPayload);
    if (shouldLoadTasks || isStaffView) {
      setTaskItems(taskPayload);
    }
   setTaskSelections(
  Object.fromEntries(
    taskPayload.map((task) => [
      task.id,
      task.assigned_staff 
        ? String(task.assigned_staff)  
        : task.assigned_staff_name
          ? String(
              staffMembers.find(s => 
                s.name === task.assigned_staff_name
              )?.id ?? ""
            )
          : ""
    ])
  )
);
    if (isStaffView) {
      try {
        const badgePayload = await getStaffPerformanceBadge();
        setStaffBadge(badgePayload.badge);
      } catch {
        setStaffBadge(null);
      }
    }
  } catch (error) {
    toast.error(error instanceof Error ? error.message : "Failed to load dashboard overview.");
  } finally {
    setLoading(false);  // ← this is what was missing
  }
};

 useEffect(() => {
  if (adminUser) void loadDashboard();
}, [adminUser]); // re-runs when auth resolves

  const kpiSnapshot = dashboardData?.kpi_snapshot ?? {
    total_leads: 0,
    todays_leads: 0,
    converted: 0,
    conversion: "0%",
    revenue_today: 0,
    order_revenue_today: 0,
    audit_revenue_today: 0,
    full_payment_revenue_today: 0,
    pending_payments: 0,
    avg_ticket_size: 0,
  };
  const staffMembers = dashboardData?.staff_members ?? [];
  const dailyRevenue = dashboardData?.daily_revenue ?? [];
  const monthlyRevenue = dashboardData?.monthly_revenue ?? [];
  const serviceRevenueBreakdown = dashboardData?.service_revenue_breakdown ?? [];
  const accessLogs = dashboardData?.access_logs ?? [];
  const pipelineOverview = dashboardData?.pipeline_overview ?? [];
  const failedLogins = dashboardData?.failed_logins ?? 0;

  const canManageTasks = isFounderView || isOpsView;
 const assignableStaff = useMemo(
  () => staffMembers.filter((staff) => {
    const role = String(staff.role || "").toLowerCase();
    if (staff.id === adminUser?.id) return false;        // never see yourself
    if (role === "admin") return false;                  // ops_manager can't see admin
    return true;
  }),
  [staffMembers, adminUser],
);
  const pendingTaskStatuses = useMemo(() => new Set(["new", "in_progress", "blocked"]), []);

  const workloadByStaff = useMemo(() => {
    const counts: Record<number, { assigned: number; pending: number; completed: number; loadStatus: string }> = {};

    for (const task of taskItems) {
      if (!task.assigned_staff) continue;
      const staffId = task.assigned_staff;
      if (!counts[staffId]) {
        counts[staffId] = { assigned: 0, pending: 0, completed: 0, loadStatus: "Active" };
      }
      counts[staffId].assigned += 1;
      if (pendingTaskStatuses.has(String(task.status || "").toLowerCase())) {
        counts[staffId].pending += 1;
      }
      if (String(task.status || "").toLowerCase() === "completed") {
        counts[staffId].completed += 1;
      }
    }

    for (const [staffId, summary] of Object.entries(counts)) {
      if (summary.pending >= 8) {
        summary.loadStatus = "Overloaded";
      } else if (summary.pending >= 3) {
        summary.loadStatus = "Busy";
      } else {
        summary.loadStatus = "Active";
      }
      counts[Number(staffId)] = summary;
    }

    return counts;
  }, [pendingTaskStatuses, taskItems]);

  const unassignedTaskCount = useMemo(
    () => taskItems.filter((task) => !task.assigned_staff).length,
    [taskItems],
  );

  const formatTaskDeadline = (deadline?: string | null) => {
    if (!deadline) {
      return "No deadline";
    }

    const parsed = new Date(deadline);
    if (Number.isNaN(parsed.getTime())) {
      return "No deadline";
    }

    return parsed.toLocaleString();
  };

 

// Change to:
const handleTaskSelectionChange = (taskId: number, value: string) => {
  setTaskSelections((prev) => ({
    ...prev,
    [taskId]: value,  // ← keep as string
  }));
};

const handleAssignTask = async (task: AdminTaskItem) => {
  const selectedStaffId = taskSelections[task.id];
  if (!selectedStaffId) {
    toast.error("Select a staff member first.");
    return;
  }

  setTaskActionLoading(task.id);
  try {
    const updatedTask = isFounderView
  ? await adminDirectAssignTask(task.id, Number(selectedStaffId))
  : await assignAdminTask(task.id, Number(selectedStaffId));

if (task.application) {
  await patchAdminApplication(task.application, {
    assigned_staff: Number(selectedStaffId),
  });
}

setTaskItems((prev) => prev.map((item) => (item.id === updatedTask.id ? updatedTask : item)));
    setTaskItems((prev) => prev.map((item) => (item.id === updatedTask.id ? updatedTask : item)));
   setTaskSelections((prev) => ({
  ...prev,
  [task.id]: updatedTask.assigned_staff ? String(updatedTask.assigned_staff) : String(selectedStaffId),
}));
    toast.success(`Task ${updatedTask.id} assigned successfully.`);
  } catch (error) {
    toast.error(error instanceof Error ? error.message : "Failed to assign task.");
  } finally {
    setTaskActionLoading(null);
  }
};

 const handleAutoAssignTasks = async () => {
  setTaskActionLoading("auto");
  try {
    const result = await autoAssignAdminTasks();
    setTaskSelections({});
    await loadDashboard();
    toast.success(`Auto-assigned ${result.assigned_count ?? 0} tasks.`);
  } catch (error) {
    toast.error(error instanceof Error ? error.message : "Failed to auto-assign tasks.");
  } finally {
    setTaskActionLoading(null);
  }
};

  const healthMetrics = useMemo(
    () => [
      ["Total Leads Generated", dashboardData?.health_metrics.total_leads ?? 0],
      ["Leads Converted", dashboardData?.health_metrics.leads_converted ?? 0],
      ["Conversion %", dashboardData?.health_metrics.conversion ?? "0%"],
      ["Revenue per Service Type", dashboardData?.health_metrics.revenue_per_service ?? "N/A"],
      ["Pending Payments", `₹${(dashboardData?.health_metrics.pending_payments ?? 0).toLocaleString("en-IN")}`],
      ["Refunds/Disputes", `₹${(dashboardData?.health_metrics.refunds_disputes ?? 0).toLocaleString("en-IN")}`],
      ["Audits Requested", dashboardData?.health_metrics.audits_requested ?? 0],
      ["Audit Success Ratio", dashboardData?.health_metrics.audit_success_ratio ?? "0%"],
      ["Avg Processing Time", dashboardData?.health_metrics.avg_processing_time ?? "0h"],
      ["Customer Satisfaction Rating", dashboardData?.health_metrics.customer_satisfaction ?? "0 / 5"],
    ],
    [dashboardData],
  );

  const insightIconMap = useMemo(() => ({ TrendingUp, Target, Workflow }), []);

  const revenueInsights = useMemo(
    () =>
      (dashboardData?.revenue_insights ?? []).map((item) => ({
        ...item,
        icon: insightIconMap[item.icon as keyof typeof insightIconMap] ?? Workflow,
      })),
    [dashboardData, insightIconMap],
  );

 const staffWorklist = useMemo(() => {
  return taskItems.map((task) => {
    const app = applications.find((a) => a.reference_number === task.application_reference);
    return {
      id: task.id,
      applicationId: task.application,  // ← confirmed field name from API
      reference: task.application_reference,
      notes: app?.notes || "",
      title: `${task.task_type.replace(/_/g, " ")} - ${task.customer_name || "Customer"}`,
      subtitle: `Status: ${task.status} • Priority: ${task.priority} • ${task.application_reference}`,
    };
  });
}, [taskItems, applications]);

  const appendTimestampedNote = (base: string, note: string) => {
    const now = new Date().toLocaleString();
    const current = (base || "").trim();
    return current ? `${current}\n[${now}] ${note}` : `[${now}] ${note}`;
  };

const handleOpenCase = (taskId: number) => {
  const task = taskItems.find((t) => t.id === taskId);
  if (!task?.application) {
    toast.error("Application not found for this task.");
    return;
  }
  // task.application is confirmed as the application ID from the API
  router.push(`/admin/kanban?applicationId=${encodeURIComponent(String(task.application))}`);
};


const handleMarkProgress = async (task: { id: number; applicationId: number; reference: string; notes: string }) => {
  try {
    await patchAdminTask(task.id, { status: "in_progress" });
    await patchAdminApplication(task.applicationId, {
      notes: appendTimestampedNote(task.notes, `Progress updated by staff for ${task.reference}`),
    });
    await loadDashboard();
    toast.success(`Progress updated for ${task.reference}`);
  } catch (error) {
    toast.error(error instanceof Error ? error.message : "Failed to update progress.");
  }
};

const handleEscalate = async (task: { id: number; applicationId: number; reference: string; notes: string }) => {
  try {
    await patchAdminTask(task.id, { status: "blocked" });
    await patchAdminApplication(task.applicationId, {
      stage: "DOCUMENTS_REQUIRED",
      correction_cause: "staff_error",
      notes: appendTimestampedNote(task.notes, `Escalated by staff for review: ${task.reference}`),
    });
    await loadDashboard();
    toast.success(`Escalation recorded for ${task.reference}`);
  } catch (error) {
    toast.error(error instanceof Error ? error.message : "Failed to escalate case.");
  }
};

const handleMarkComplete = async (task: { id: number; applicationId: number; reference: string; notes: string }) => {
  try {
    await patchAdminTask(task.id, { status: "completed" });
    await patchAdminApplication(task.applicationId, {
      notes: appendTimestampedNote(task.notes, `Task completed by staff for ${task.reference}`),
    });
    await loadDashboard();
    toast.success(`Task marked complete for ${task.reference}`);
  } catch (error) {
    toast.error(error instanceof Error ? error.message : "Failed to mark task complete.");
  }
};

 
  const accountabilityFeed = useMemo(() => {
    return [...applications]
      .sort((left, right) => {
        const leftTs = new Date(left.updated_at || left.created_at).getTime();
        const rightTs = new Date(right.updated_at || right.created_at).getTime();
        return rightTs - leftTs;
      })
      .slice(0, 3)
      .map((app) => {
        const status = String(app.application_status || "").replace(/_/g, " ");
        const updatedTime = new Date(app.updated_at || app.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        return {
          id: app.id,
          text: `${status.charAt(0).toUpperCase()}${status.slice(1)} | ${app.reference_number} | ${updatedTime}`,
        };
      });
  }, [applications]);

  if (loading) {
  return (
    <div className="flex items-center justify-center h-64 text-[#627D98] text-sm">
      Loading dashboard...
    </div>
  );
}

  return (
    <div className="animate-in fade-in zoom-in-95 duration-500 max-w-[1500px] mx-auto space-y-6 font-body">
      <div className="flex justify-between items-center mb-2">
        <div>
          <h1 className="text-[26px] leading-tight font-heading font-semibold text-[#102A43]">FlyOCI Console</h1>
          <p className="text-[#486581] text-sm mt-1">{roleLabel} dashboard overview</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-7 gap-4 mb-6">
        <StatCard 
          title="Total Leads" 
          value={kpiSnapshot.total_leads}
          trend="Last 30 days"
          isPositive={true} 
          icon={Users}
          colorClass="text-[#009877]"
          bgClass="bg-[#009877]/10"
        />
        <StatCard 
          title="Today's Leads" 
          value={kpiSnapshot.todays_leads}
          trend="Live"
          isPositive={true} 
          icon={Briefcase}
          colorClass="text-[#33A1FD]"
          bgClass="bg-[#33A1FD]/10"
        />
        <StatCard 
          title="Leads Converted"
          value={kpiSnapshot.converted}
          trend={kpiSnapshot.conversion}
          isPositive={true} 
          icon={SearchCheck}
          colorClass="text-[#009877]"
          bgClass="bg-[#009877]/10"
        />
        <StatCard 
          title="Total Revenue ₹" 
          value={`₹${kpiSnapshot.revenue_today.toLocaleString("en-IN")}`}
          trend="Today"
          isPositive={true}
          icon={IndianRupee}
          colorClass="text-[#B87333]"
          bgClass="bg-[#B87333]/10"
        />
        <StatCard 
          title="Audit Revenue ₹"
          value={`₹${(kpiSnapshot.audit_revenue_today ?? 0).toLocaleString("en-IN")}`}
          trend="Today"
          isPositive={true}
          icon={ShieldCheck}
          colorClass="text-[#0F766E]"
          bgClass="bg-[#0F766E]/10"
        />
        <StatCard 
          title="Avg. Ticket Size" 
          value={`₹${kpiSnapshot.avg_ticket_size.toLocaleString("en-IN")}`}
          trend="Rolling"
          isPositive={true} 
          icon={Banknote}
          colorClass="text-[#33A1FD]"
          bgClass="bg-[#33A1FD]/10"
        />
        <StatCard 
          title="Pending Payments" 
          value={`₹${kpiSnapshot.pending_payments.toLocaleString("en-IN")}`}
          trend="Attention"
          isPositive={false}
          icon={Clock}
          colorClass="text-[#DC2626]"
          bgClass="bg-[#DC2626]/10"
        />
      </div>

      {canManageTasks && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          <div className="bg-white rounded-[12px] border-[0.5px] border-[#D9E1EA] p-5">
            <div className="flex justify-between items-center mb-3">
              <h2 className="text-lg font-heading font-semibold text-[#102A43]">Workload Distribution</h2>
             <div className="flex gap-2">
  <button
    onClick={() => void loadDashboard()}
    className="inline-flex items-center gap-2 bg-[#009877] text-white px-4 py-2 rounded-[10px] text-sm font-heading font-semibold hover:bg-[#007B61] disabled:opacity-60"
    disabled={taskActionLoading === "auto"}
  >
    <RefreshCw className="w-4 h-4" />
    REFRESH
  </button>
  <button
    onClick={() => void handleAutoAssignTasks()}
    disabled={taskActionLoading === "auto"}
    className="inline-flex items-center gap-2 bg-[#33A1FD] text-white px-4 py-2 rounded-[10px] text-sm font-heading font-semibold hover:bg-[#0B69B7] disabled:opacity-60"
  >
    {taskActionLoading === "auto" ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Shuffle className="w-4 h-4" />}
    {taskActionLoading === "auto" ? "Assigning..." : "AUTO ASSIGN"}
  </button>
</div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {staffMembers
  .filter((item) => item.id !== adminUser?.id)
  .map((item) => (
                (() => {
                  const summary = workloadByStaff[item.id] || {
                    assigned: 0,
                    pending: 0,
                    completed: 0,
                    loadStatus: item.loadStatus,
                  };
                  return (
                <div key={item.id} className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-3">
                  <p className="text-[#102A43] font-heading font-semibold">{item.name} ({item.initials})</p>
                  <p className="text-xs text-[#627D98]">{item.role}</p>
                  <div className="mt-2 flex gap-2 text-xs flex-wrap">
                    <span className="bg-[#33A1FD]/12 text-[#0B69B7] px-2 py-1 rounded-full">Assigned {summary.assigned}</span>
                    <span className="bg-[#B87333]/12 text-[#9C4F17] px-2 py-1 rounded-full">Pending {summary.pending}</span>
                  </div>
                  <p className="text-xs mt-2 text-[#627D98]">Status: {summary.loadStatus}</p>
                </div>
                  );
                })()
              ))}
            </div>
          </div>

       <div className="space-y-3 max-h-[520px] overflow-y-auto pr-1">
  {taskItems.length === 0 && (
    <p className="text-sm text-[#627D98]">No queued tasks are available right now.</p>
  )}
  {taskItems.map((task) => {
    const isBusy = taskActionLoading === task.id;
    const selectedStaffId = taskSelections[task.id] ?? task.assigned_staff ?? "";
    const isCompleted = task.status === "completed";
    const isCancelled = task.status === "cancelled";
    const isClosedOut = isCompleted || isCancelled;

    return (
      <div
        key={task.id}
        className={`rounded-[12px] border p-3 ${
          isCompleted
            ? "border-[#009877]/30 bg-[#F0FBF8]"
            : isCancelled
            ? "border-[#D9E1EA] bg-[#F5F7FA] opacity-60"
            : "border-[#D9E1EA] bg-[#F8FAFC]"
        }`}
      >
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-sm font-heading font-semibold text-[#102A43]">
              {task.application_reference}
            </p>
            <p className="text-xs text-[#627D98] capitalize">
              {task.task_type.replace(/_/g, " ")} • {task.customer_name || "Customer"}
            </p>
            <p className="text-xs text-[#627D98] mt-1">
              Due: {formatTaskDeadline(task.deadline)}
            </p>
          </div>
          <div className="flex flex-wrap gap-2 text-[11px]">
            <span
              className={`rounded-full px-2.5 py-1 ${
                isCompleted
                  ? "bg-[#009877]/20 text-[#006F57] font-semibold"
                  : task.status === "blocked"
                  ? "bg-[#DC2626]/12 text-[#B42318]"
                  : task.status === "in_progress"
                  ? "bg-[#33A1FD]/12 text-[#0B69B7]"
                  : "bg-[#009877]/12 text-[#006F57]"
              }`}
            >
              {isCompleted ? "✓ Completed" : task.status}
            </span>
            <span className="rounded-full bg-[#B87333]/12 px-2.5 py-1 text-[#9C4F17]">
              {task.priority}
            </span>
            <span className="rounded-full bg-[#33A1FD]/12 px-2.5 py-1 text-[#0B69B7]">
              {task.assigned_staff_name || "Unassigned"}
            </span>
          </div>
        </div>

        {isClosedOut ? (
          // Completed/cancelled — show read-only summary, no assignment controls
          <div className="mt-3 rounded-[8px] border border-[#D9E1EA] bg-white px-3 py-2 text-xs text-[#627D98]">
            {isCompleted
              ? "This task has been completed. No further action needed."
              : "This task has been cancelled."}
          </div>
        ) : (
          // Active task — show assignment controls
          <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center">
            <select
              value={selectedStaffId}
              onChange={(event) => handleTaskSelectionChange(task.id, event.target.value)}
              className="w-full sm:flex-1 rounded-[10px] border border-[#D9E1EA] bg-white px-3 py-2 text-sm text-[#102A43] outline-none focus:border-[#33A1FD]"
            >
              <option value="">Select staff member</option>
              {assignableStaff.map((staff) => (
                <option key={staff.id} value={staff.id}>
                  {staff.name} - {staff.role}
                </option>
              ))}
            </select>
            <button
              onClick={() => void handleAssignTask(task)}
              disabled={isBusy || assignableStaff.length === 0}
              className="inline-flex items-center justify-center gap-2 rounded-[10px] bg-[#009877] px-4 py-2 text-sm font-heading font-semibold text-white hover:bg-[#007B61] disabled:opacity-60"
            >
              {isBusy ? <RefreshCw className="w-4 h-4 animate-spin" /> : <UserCog className="w-4 h-4" />}
              {isBusy ? "Saving..." : "Assign"}
            </button>
          </div>
        )}

        <p className="mt-2 text-[11px] text-[#627D98]">
          Current assignee:{" "}
          <span className="text-[#102A43] font-medium">
            {task.assigned_staff_name || "None"}
          </span>
          {isFounderView && task.assigned_staff_role ? (
            <span className="ml-2 inline-flex items-center gap-1 rounded-full bg-[#EAF5FF] px-2 py-0.5 text-[#2B5E93]">
              <UserRoundCog className="w-3 h-3" />
              {task.assigned_staff_role}
            </span>
          ) : null}
        </p>
      </div>
    );
  })}
</div>

        </div>
      )}


{isOpsView && (
  <div className="bg-white rounded-[12px] border-[0.5px] border-[#D9E1EA] p-5">
    <h2 className="text-lg font-heading font-semibold text-[#102A43] mb-4">
      My Assigned Tasks
    </h2>
    <div className="space-y-3">
      {taskItems.filter(t => t.assigned_staff === adminUser?.id).length === 0 ? (
        <p className="text-sm text-[#627D98]">No tasks currently assigned to you.</p>
      ) : (
        taskItems
          .filter(t => t.assigned_staff === adminUser?.id)
          .map((task) => (
            <div key={task.id} className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-3 flex items-center justify-between gap-3">
              <div>
                <p className="text-[#102A43] text-sm font-medium">{task.application_reference}</p>
                <p className="text-xs text-[#627D98] capitalize">
                  {task.task_type.replace(/_/g, " ")} • {task.customer_name}
                </p>
                <p className="text-xs text-[#627D98]">Due: {formatTaskDeadline(task.deadline)}</p>
              </div>
              <div className="flex gap-2 flex-wrap justify-end">
                <span className="rounded-full bg-[#009877]/12 px-2.5 py-1 text-[11px] text-[#006F57]">{task.status}</span>
                <span className="rounded-full bg-[#B87333]/12 px-2.5 py-1 text-[11px] text-[#9C4F17]">{task.priority}</span>
                <button
                  className="text-xs bg-[#33A1FD]/12 text-[#0B69B7] border-[0.5px] border-[#33A1FD]/35 px-2 py-1 rounded-full"
                  onClick={() => handleOpenCase(task.id)}
                >
                  Open Case
                </button>
              </div>
            </div>
          ))
      )}
    </div>
  </div>
)}

      {!isFounderView && !isOpsView && !isStaffView && (
        <div className="bg-white rounded-[12px] border-[0.5px] border-[#D9E1EA] p-4">
          <p className="text-sm text-[#486581]">
            Read-only mode active for this role. Strategic reports remain restricted to Admin / CEO and Operations Manager.
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-[12px] border-[0.5px] border-[#D9E1EA] p-5">
          <h2 className="text-lg font-heading font-semibold text-[#102A43] mb-4">Revenue Dashboard</h2>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={dailyRevenue}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5EAF0" />
                <XAxis dataKey="day" tick={{ fill: "#486581", fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#486581", fontSize: 12 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "#FFFFFF", border: "0.5px solid #D9E1EA", color: "#102A43", borderRadius: "12px" }} />
                <Bar dataKey="expected" fill="#33A1FD" radius={[6, 6, 0, 0]} />
                <Line type="monotone" dataKey="actual" stroke="#B87333" strokeWidth={3} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-[12px] border-[0.5px] border-[#D9E1EA] p-5">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-heading font-semibold text-[#102A43]">Revenue Split</h2>
            <span className="bg-[#33A1FD]/12 text-[#0B69B7] text-xs font-heading font-semibold px-2 py-0.5 rounded-full">Live</span>
          </div>
          <div className="h-[260px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={serviceRevenueBreakdown} dataKey="value" nameKey="name" outerRadius={90}>
                  {serviceRevenueBreakdown.map((_, index) => (
                    <Cell key={index} fill={chartColors[index % chartColors.length]} />
                  ))}
                </Pie>
                <Legend />
                <Tooltip contentStyle={{ background: "#FFFFFF", border: "0.5px solid #D9E1EA", color: "#102A43", borderRadius: "12px" }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-[12px] border-[0.5px] border-[#D9E1EA] overflow-hidden">
        <div className="p-5 border-b border-[0.5px] border-[#D9E1EA] flex items-center justify-between">
          <h2 className="text-lg font-heading font-semibold text-[#102A43]">Business Health Metrics</h2>
          <div className="flex gap-2">
            {(["Daily", "Weekly", "Monthly"] as const).map((item) => (
              <button
                key={item}
                onClick={() => setPeriod(item)}
                className={`text-xs px-3 py-1 rounded-full font-heading ${period === item ? "bg-[#009877] text-white" : "bg-[#F5F7FA] text-[#486581]"}`}
              >
                {item}
              </button>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-4">
          {healthMetrics.map(([label, value]) => (
            <div key={label} className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-3 flex justify-between">
              <span className="text-[#486581] text-sm">{label}</span>
              <span className="text-[#102A43] font-heading font-semibold text-sm">{value}</span>
            </div>
          ))}
        </div>
      </div>

      {isFounderView && (
        <div className="rounded-[14px] border border-[#D9E1EA] bg-[#F8FCFF] p-5 sm:p-6">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
            <h2 className="text-lg font-heading font-semibold text-[#102A43]">Work Pipeline Overview</h2>
            <div className="flex flex-wrap gap-2.5">
              <span className="text-[11px] px-3 py-1.5 rounded-full bg-[#EAF5FF] text-[#2B5E93] border border-[#CFE4F8]">Service Type</span>
              <span className="text-[11px] px-3 py-1.5 rounded-full bg-[#EAF5FF] text-[#2B5E93] border border-[#CFE4F8]">Country</span>
              <span className="text-[11px] px-3 py-1.5 rounded-full bg-[#EAF5FF] text-[#2B5E93] border border-[#CFE4F8]">Staff</span>
              <span className="text-[11px] px-3 py-1.5 rounded-full bg-[#ECFAF5] text-[#1F6A4A] border border-[#CDEBDD]">Ageing 3+/5+/7+ days</span>
            </div>
          </div>

          <div className="mb-3 text-xs text-[#627D98]">Scroll horizontally to review all pipeline stages</div>

          <div className="overflow-x-auto pb-2">
            <div className="flex gap-3 min-w-max snap-x snap-mandatory">
            {pipelineOverview.map((item, idx) => (
              <div
                key={item.stage}
                className="min-w-[220px] max-w-[220px] snap-start rounded-[12px] border border-[#CFE4F8] bg-white p-3.5 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_12px_26px_rgba(40,98,160,0.10)]"
              >
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <p className="text-[11px] text-[#6E8BAA]">Stage {idx + 1}</p>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full border ${item.breached > 0 ? "bg-[#FFF1F0] text-[#B42318] border-[#F2C7C3]" : "bg-[#ECFAF5] text-[#1F6A4A] border-[#CDEBDD]"}`}>
                    {item.breached > 0 ? `${item.breached} breach` : "Healthy"}
                  </span>
                </div>
                <p className="text-[18px] font-heading font-semibold text-[#102A43] leading-tight">{item.stage}</p>

                <div className="mt-3 space-y-2">
                  <p className="text-xs text-[#486581] flex items-center justify-between"><span>Open Cases</span><span className="font-semibold text-[#102A43]">{item.openCases}</span></p>
                  <p className="text-xs text-[#486581] flex items-center justify-between"><span>Average Age</span><span className="font-semibold text-[#102A43]">{item.avgAge}</span></p>
                  <p className="text-xs text-[#486581] flex items-center justify-between"><span>SLA Breach</span><span className="font-semibold text-[#102A43]">{item.breached}</span></p>
                </div>
              </div>
            ))}
            </div>
          </div>
        </div>
      )}

      {isFounderView && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {revenueInsights.map((item) => (
            <div key={item.label} className="bg-white rounded-[12px] border-[0.5px] border-[#D9E1EA] p-4">
              <p className="text-xs text-[#627D98]">{item.label}</p>
              <p className="text-lg font-heading font-semibold text-[#102A43] mt-1 inline-flex items-center gap-2">
                <item.icon className="w-4 h-4 text-[#009877]" />
                {item.value}
              </p>
              <p className="text-xs text-[#8A9BB0] mt-1">{item.note}</p>
            </div>
          ))}
        </div>
      )}

      {isFounderView && (
        <div className="space-y-2">
          <details className="bg-white border border-[#D9E1EA] rounded-[12px] p-3 group">
            <summary className="list-none cursor-pointer text-sm font-heading font-semibold text-[#102A43] flex items-center justify-between">
              Founder insight: conversion bottlenecks
              <span className="text-[#627D98] group-open:rotate-180 transition-transform">⌄</span>
            </summary>
            <p className="mt-2 text-sm text-[#486581]">The largest drop is between audit completion and payment. Priority action: automate payment nudges within first 30 minutes.</p>
          </details>
          <details className="bg-white border border-[#D9E1EA] rounded-[12px] p-3 group">
            <summary className="list-none cursor-pointer text-sm font-heading font-semibold text-[#102A43] flex items-center justify-between">
              Founder insight: staffing strategy
              <span className="text-[#627D98] group-open:rotate-180 transition-transform">⌄</span>
            </summary>
            <p className="mt-2 text-sm text-[#486581]">Reassign high-complexity audits to top-accuracy staff to reduce repeat corrections and overall cycle time.</p>
          </details>
        </div>
      )}

      {isFounderView ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white rounded-[12px] border-[0.5px] border-[#D9E1EA] overflow-hidden">
            <div className="p-5 border-b border-[0.5px] border-[#D9E1EA]">
              <h2 className="text-lg font-heading font-semibold text-[#102A43]">Team Performance Grid</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left align-middle">
                <thead className="bg-[#F5F7FA] text-[#486581] font-heading font-medium">
                  <tr>
                    <th className="px-5 py-3 font-medium">Staff Name</th>
                    <th className="px-5 py-3 font-medium text-center">Assigned</th>
                    <th className="px-5 py-3 font-medium text-center">Completed</th>
                    <th className="px-5 py-3 font-medium text-center">Pending</th>
                    <th className="px-5 py-3 font-medium text-center">Avg Time/Task</th>
                    <th className="px-5 py-3 font-medium text-center">SLA Breaches</th>
                    <th className="px-5 py-3 font-medium text-center">Accuracy Score</th>
                    <th className="px-5 py-3 font-medium text-center">Audits P/F</th>
                  </tr>
                </thead>
              <tbody className="divide-y divide-[#E5EAF0]">
  {staffMembers
    .filter((staff) => String(staff.role || "").toLowerCase() !== "admin")
    .map((staff) => {
      const live = workloadByStaff[staff.id];
      // Use live task counts if available, fall back to API data
      const assigned = live?.assigned ?? staff.assigned;
      const completed = live?.completed ?? staff.completed;
      const pending = live?.pending ?? staff.pending;

      return (
        <tr key={staff.id} className="hover:bg-[#F8FAFC] transition-colors">
          <td className="px-5 py-3 text-[#102A43] font-medium">
            {staff.name}
            <span className="ml-2 text-[11px] text-[#627D98] font-normal">{staff.role}</span>
          </td>
          <td className="px-5 py-3 text-center font-semibold text-[#0B69B7]">
            {assigned}
          </td>
          <td className="px-5 py-3 text-center font-semibold text-[#006F57]">
            {completed}
          </td>
          <td className="px-5 py-3 text-center font-semibold text-[#9C4F17]">
            {pending}
          </td>
          <td className="px-5 py-3 text-center text-[#486581]">
            {staff.avgTime}
          </td>
          <td className="px-5 py-3 text-center">
            <span className={staff.slaBreach > 0 ? "text-[#B42318] font-semibold" : "text-[#486581]"}>
              {staff.slaBreach}
            </span>
          </td>
          <td className="px-5 py-3 text-center">
            <span className={`font-semibold ${
              staff.accuracy >= 90
                ? "text-[#006F57]"
                : staff.accuracy >= 70
                ? "text-[#9C4F17]"
                : "text-[#B42318]"
            }`}>
              {staff.accuracy}%
            </span>
          </td>
          <td className="px-5 py-3 text-center">
            <span className="text-[#006F57] font-semibold">{staff.auditsPassed}</span>
            <span className="text-[#627D98] mx-0.5">/</span>
            <span className="text-[#B42318] font-semibold">{staff.auditsFailed}</span>
          </td>
        </tr>
      );
    })}
  {staffMembers.filter((s) => String(s.role || "").toLowerCase() !== "admin").length === 0 && (
    <tr>
      <td colSpan={8} className="px-5 py-6 text-center text-sm text-[#627D98]">
        No staff members found.
      </td>
    </tr>
  )}
</tbody>
              </table>
            </div>
          </div>

          <div className="bg-white rounded-[12px] border-[0.5px] border-[#D9E1EA] p-5">
            <h2 className="text-lg font-heading font-semibold text-[#102A43] mb-4">Security & Compliance</h2>
            <div className="space-y-3">
              <div className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-3 flex items-center justify-between">
                <span className="text-[#486581] text-sm flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-[#B42318]" /> Failed logins</span>
                <span className="text-[#B42318] font-heading font-semibold">{failedLogins}</span>
              </div>
              <div className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-3">
                <p className="text-[#486581] text-sm mb-2">Recent data access log</p>
                {accessLogs.map((log) => (
                  <p key={`${log.staff}-${log.time}`} className="text-xs text-[#627D98]">
                    {log.staff} | {log.file} | {log.time}
                  </p>
                ))}
              </div>
              <div className="bg-[#009877]/12 text-[#006F57] border-[0.5px] border-[#009877]/35 text-sm px-3 py-2 rounded-[12px] inline-flex items-center gap-2">
                <ShieldCheck className="w-4 h-4" /> All Documents Encrypted
              </div>
            </div>
          </div>
        </div>
      ) : isStaffView ? (
        <div className="bg-white rounded-[12px] border-[0.5px] border-[#D9E1EA] p-5">
          <h2 className="text-lg font-heading font-semibold text-[#102A43] mb-4">My Daily Worklist</h2>
          <div className="mb-4 rounded-[12px] border border-[#D9E1EA] bg-[#F8FCFF] px-4 py-3">
            <p className="text-xs text-[#627D98]">My Performance Badge</p>
            <p className="mt-1 text-lg font-heading font-semibold text-[#102A43]">{staffBadge || "Needs Improvement"}</p>
          </div>
          <div className="space-y-3">

            
            {staffWorklist.map((task) => (
              <div key={task.id} className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-3 flex items-center justify-between gap-3">
                <div>
                  <p className="text-[#102A43] text-sm font-medium">{task.title}</p>
                  <p className="text-xs text-[#627D98]">{task.subtitle}</p>
                </div>
                <div className="flex gap-2 flex-wrap justify-end">
                  <button className="text-xs bg-[#33A1FD]/12 text-[#0B69B7] border-[0.5px] border-[#33A1FD]/35 px-2 py-1 rounded-full" onClick={() => handleOpenCase(task.id)}>Open Case</button>
                  <button className="text-xs bg-[#009877]/12 text-[#006F57] border-[0.5px] border-[#009877]/35 px-2 py-1 rounded-full" onClick={() => void handleMarkProgress(task)}>Mark Progress</button>
                  <button className="text-xs bg-[#B87333]/12 text-[#9C4F17] border-[0.5px] border-[#B87333]/35 px-2 py-1 rounded-full" onClick={() => void handleEscalate(task)}>Escalate</button>
                  <button 
  className="text-xs bg-[#009877]/12 text-[#006F57] border-[0.5px] border-[#009877]/35 px-2 py-1 rounded-full" 
  onClick={() => void handleMarkComplete(task)}
>
  Mark Complete
</button>
                </div>
              </div>
            ))}


            {staffWorklist.length === 0 && <p className="text-sm text-[#627D98]">No active work items found.</p>}
          </div>
          <h3 className="text-[#102A43] font-heading font-semibold mt-6 mb-2">Accountability Panel</h3>
          <div className="bg-white border-[0.5px] border-[#D9E1EA] rounded-[12px] p-3 space-y-1">
            {accountabilityFeed.map((item) => (
              <p key={item.id} className="text-xs text-[#627D98]">{item.text}</p>
            ))}
            {accountabilityFeed.length === 0 && <p className="text-xs text-[#627D98]">No recent activity.</p>}
          </div>
        </div>
      ) : null}

      <div className="bg-white rounded-[12px] border-[0.5px] border-[#D9E1EA] p-5">
        <h2 className="text-lg font-heading font-semibold text-[#102A43] mb-4">Monthly Revenue Trend</h2>
        <div className="h-[220px]">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={monthlyRevenue}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5EAF0" />
              <XAxis dataKey="month" tick={{ fill: "#486581", fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#486581", fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: "#FFFFFF", border: "0.5px solid #D9E1EA", color: "#102A43", borderRadius: "12px" }} />
              <Line type="monotone" dataKey="revenue" stroke="#009877" strokeWidth={3} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

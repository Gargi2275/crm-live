"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";
import { useAdminAuth } from "@/context/AdminAuthContext";
import {
  BarChart3,
  Briefcase,
  Users,
  KanbanSquare,
  PieChart,
  TriangleAlert,
  Landmark,
  CreditCard,
  Settings,
  ChevronLeft,
  ChevronRight,
  Plane,
  List,
  CalendarClock,
  TrendingUp,
} from "lucide-react";


export function Sidebar({ collapsed, setCollapsed }: { collapsed: boolean, setCollapsed: (val: boolean) => void }) {
  const pathname = usePathname();
  const { adminUser } = useAdminAuth();

  const role = adminUser?.role;
  const accessScope = adminUser?.access_scope ?? "all";

  const [easyFlyOpen, setEasyFlyOpen] = useState(accessScope === "easyfly_only" || pathname?.startsWith("/admin/easyfly"));

  useEffect(() => {
    setEasyFlyOpen(accessScope === "easyfly_only" || Boolean(pathname?.startsWith("/admin/easyfly")));
  }, [accessScope, pathname]);

  const easyFlySubItems = [
    { name: "Bookings", href: "/admin/easyfly", icon: List },
    { name: "Schedule Changes", href: "/admin/easyfly/schedule", icon: CalendarClock },
    ...(role === "admin" ? [{ name: "Revenue", href: "/admin/easyfly/revenue", icon: TrendingUp }] : []),
  ];

  const baseMenuItems = [
    { name: "Dashboard", href: "/admin", icon: BarChart3 },
    { name: "Staff Management", href: "/admin/staff", icon: Briefcase },
    { name: "Kanban Pipeline", href: "/admin/kanban", icon: KanbanSquare },
    { name: "Reports", href: "/admin/reports", icon: PieChart },
     { name: "EasyFly Bookings", href: "/admin/easyfly", icon: Plane },
    { name: "NDR / SLA Alerts", href: "/admin/alerts", icon: TriangleAlert },
    { name: "Team Management", href: "/admin/team", icon: Users },
    { name: "Remittance / Revenue", href: "/admin/revenue", icon: Landmark },
    { name: "Billing", href: "/admin/billing", icon: CreditCard },
    { name: "Settings", href: "/admin/settings", icon: Settings },
    // EasyFly removed from here
  ];

  const menuItems = baseMenuItems.filter((item) => {
    if (accessScope === "easyfly_only") {
      return item.href === "/admin/easyfly";
    }

    if (accessScope === "exclude_easyfly") {
      if (item.href === "/admin/easyfly") return false;
    }

    if (role === "admin") return true;
    if (role === "ops_manager") {
      return !["/admin/revenue", "/admin/billing", "/admin/staff", "/j/staff"].includes(item.href);
    }
    if (role === "case_processor") {
      return ["/admin", "/admin/kanban", "/admin/easyfly"].includes(item.href);
    }
    if (role === "reviewer") {
      return ["/admin", "/admin/kanban", "/admin/reports", "/admin/easyfly"].includes(item.href);
    }
    if (role === "support_agent") {
      return ["/admin"].includes(item.href);
    }
    return item.href === "/admin";
  });

  return (
    <aside 
      className={cn(
        "bg-white border-r border-[0.5px] border-[#D9E1EA] h-screen sticky top-0 flex flex-col transition-all duration-300 z-20",
        collapsed ? "w-[64px]" : "w-[220px]"
      )}
    >
      {/* Logo Header */}
      <div className="h-16 flex items-center justify-between px-4 border-b border-[0.5px] border-[#D9E1EA]">
        <Link href="/" className={cn("flex items-center gap-2", collapsed && "justify-center w-full")}>
          <Image
            src="/logo.png"
            alt="FlyOCI Logo"
            width={120}
            height={40}
            className={cn("object-contain", collapsed ? "h-8 w-8" : "h-10 w-auto")}
            priority
          />
        </Link>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 py-4 overflow-y-auto px-2 space-y-1">
        {menuItems.map((item) => {
          const isActive = pathname === item.href || (item.href !== "/admin" && pathname?.startsWith(item.href));
          // EasyFly dropdown logic
          if (item.href === "/admin/easyfly") {
            if (accessScope === "exclude_easyfly") return null;
            return (
              <div key="easyfly-dropdown">
                <motion.div
                  whileHover={{ x: collapsed ? 0 : 2 }}
                  whileTap={{ scale: 0.99 }}
                  className={cn(
                    "relative flex items-center gap-3 px-3 py-2.5 rounded-[12px] transition-colors group font-body cursor-pointer",
                    (pathname?.startsWith("/admin/easyfly"))
                      ? "bg-[#009877]/12 text-[#006F57] font-semibold border border-[0.5px] border-[#009877]/40 shadow-[0_8px_22px_rgba(0,152,119,0.08)]"
                      : "text-slate-600 hover:bg-[#F5F7FA] hover:text-slate-900 border border-transparent",
                    collapsed && "justify-center px-0"
                  )}
                  onClick={() => !collapsed && setEasyFlyOpen((v) => !v)}
                  title={collapsed ? item.name : undefined}
                >
                  <Plane
                    className={cn(
                      "w-5 h-5 shrink-0 transition-transform duration-300",
                      pathname?.startsWith("/admin/easyfly") ? "text-[#009877]" : "text-slate-500 group-hover:text-slate-800 group-hover:scale-105",
                    )}
                  />
                  {!collapsed && <span className="truncate">EasyFly</span>}

                </motion.div>
                {/* Dropdown */}
                <AnimatePresence>
                  {!collapsed && easyFlyOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <div className="ml-7 border-l border-[#D9E1EA] pl-3 py-1 flex flex-col gap-1">
                        {easyFlySubItems.map((sub) => (
                          <Link
                            key={sub.href}
                            href={sub.href}
                            className={cn(
                              "flex items-center gap-2 px-2 py-2 rounded-[8px] transition-colors font-body text-sm",
                              pathname === sub.href || pathname?.startsWith(sub.href)
                                ? "bg-[#009877]/10 text-[#006F57] font-semibold"
                                : "text-slate-600 hover:bg-[#F5F7FA] hover:text-slate-900"
                            )}
                          >
                            <sub.icon className="w-4 h-4 shrink-0" />
                            <span className="truncate">{sub.name}</span>
                          </Link>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          }
          // Default nav item
          return (
            <motion.div key={item.href} whileHover={{ x: collapsed ? 0 : 2 }} whileTap={{ scale: 0.99 }}>
              <Link
                href={item.href}
                className={cn(
                  "relative flex items-center gap-3 px-3 py-2.5 rounded-[12px] transition-colors group font-body",
                  isActive
                    ? "bg-[#009877]/12 text-[#006F57] font-semibold border border-[0.5px] border-[#009877]/40 shadow-[0_8px_22px_rgba(0,152,119,0.08)]"
                    : "text-slate-600 hover:bg-[#F5F7FA] hover:text-slate-900 border border-transparent",
                  collapsed && "justify-center px-0"
                )}
                title={collapsed ? item.name : undefined}
              >
                <item.icon
                  className={cn(
                    "w-5 h-5 shrink-0 transition-transform duration-300",
                    isActive ? "text-[#009877]" : "text-slate-500 group-hover:text-slate-800 group-hover:scale-105",
                  )}
                />
                {!collapsed && <span className="truncate">{item.name}</span>}
              </Link>
            </motion.div>
          );
        })}
      </nav>

      {/* Collapse Toggle */}
      <div className="p-3 border-t border-[0.5px] border-[#D9E1EA] flex justify-center">
        <motion.button 
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 rounded-[10px] text-slate-500 hover:bg-[#F5F7FA] hover:text-slate-800 transition-colors w-full flex justify-center"
          title={collapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          {collapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
        </motion.button>
      </div>
    </aside>
  );
}
